/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg04;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
public class Activity_01_Binary_Search {
    public static int binarySearch(int[] arr, int target) {

        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {

            int mid = (low + high) / 2;

            if (arr[mid] == target) {
                return mid;
            } 
            else if (arr[mid] < target) {
                low = mid + 1;
            } 
            else {
                high = mid - 1;
            }
        }

        return -1;
    }
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int[] binaryArray = {12, 23, 34, 45, 56, 78, 89};

        System.out.print("Enter target value: ");
        int target = input.nextInt();

        int result = binarySearch(binaryArray, target);

        System.out.println("\nTarget value: " + target);

        if (result != -1) {
            System.out.println("Binary Search: Element found");
            System.out.println("Index position: " + result);
        } else {
            System.out.println("Binary Search: Element not found");
            System.out.println("Index position: -1");
        }
        input.close();
    }
}
