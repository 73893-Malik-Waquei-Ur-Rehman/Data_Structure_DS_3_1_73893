/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg04;

/**
 *
 * @author Pc
 */

public class Activity_03_Queue_Operations {
    // Fixed capacity of Queue
    int[] queue = new int[5];

    int front = -1;
    int rear = -1;
    // Enqueue - Insert element at the rear
    void enqueue(int value) {
        if (rear == queue.length - 1) {
            System.out.println("Queue Overflow! Queue is full.");
        } else {
            if (front == -1) {
                front = 0;
            }

            rear++;
            queue[rear] = value;
            System.out.println(value + " enqueued.");
        }
    }
    // Dequeue - Remove element from the front
    void dequeue() {
        if (front == -1 || front > rear) {
            System.out.println("Queue Underflow! Queue is empty.");
        } else {
            System.out.println(queue[front] + " dequeued.");
            front++;

            // Reset queue when it becomes empty
            if (front > rear) {
                front = -1;
                rear = -1;
            }
        }
    }
    // Peek - Display front element
    void peek() {
        if (front == -1 || front > rear) {
            System.out.println("Queue is empty.");
        } else {
            System.out.println("Front element: " + queue[front]);
        }
    }
    // Display - Display all elements
    void display() {
        if (front == -1 || front > rear) {
            System.out.println("Queue is empty.");
        } else {
            System.out.print("Queue elements: ");

            for (int i = front; i <= rear; i++) {
                System.out.print(queue[i] + " ");
            }

            System.out.println();
        }
    }
    // Main method
    public static void main(String[] args) {

        Activity_03_Queue_Operations q = new Activity_03_Queue_Operations();
        // Enqueue 10
        q.enqueue(10);
        // Enqueue 20
        q.enqueue(20);
        // Enqueue 30
        q.enqueue(30);
        // Display
        q.display();
        // Peek
        q.peek();
        // Dequeue
        q.dequeue();
        // Display
        q.display();
    }
}

