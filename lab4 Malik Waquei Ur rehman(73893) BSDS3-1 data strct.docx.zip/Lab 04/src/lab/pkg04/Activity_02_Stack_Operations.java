/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg04;

/**
 *
 * @author Pc
 */


public class Activity_02_Stack_Operations {
    // Stack capacity
    static final int MAX = 5;
    // Array to store stack elements
    int[] stack = new int[MAX];
    // Top of the stack
    int top = -1;
    // Push method
    public void push(int value) {

        if (top == MAX - 1) {
            System.out.println("Stack Overflow! Stack is full.");
        } else {
            top++;
            stack[top] = value;
            System.out.println(value + " pushed into the Stack.");
        }
    }
    // Pop method
    public void pop() {

        if (top == -1) {
            System.out.println("Stack Underflow! Stack is empty.");
        } else {
            System.out.println(stack[top] + " popped from the Stack.");
            top--;
        }
    }
    // Peek method
    public void peek() {

        if (top == -1) {
            System.out.println("Stack is empty. Nothing to peek.");
        } else {
            System.out.println("Top element: " + stack[top]);
        }
    }
    // Display method
    public void display() {

        if (top == -1) {
            System.out.println("Stack is empty.");
        } else {
            System.out.println("Stack elements:");

            for (int i = top; i >= 0; i--) {
                System.out.println(stack[i]);
            }
        }
    }
    public static void main(String[] args) {

        Activity_02_Stack_Operations s = new Activity_02_Stack_Operations();
        // Push operations
        s.push(10);
        s.push(20);
        s.push(30);
        // Display stack
        s.display();
        // Peek top element
        s.peek();
        // Pop top element
        s.pop();
        // Display stack after pop
        s.display();
    }
}
