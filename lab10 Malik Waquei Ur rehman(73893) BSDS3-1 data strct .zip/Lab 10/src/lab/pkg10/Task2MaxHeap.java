/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg10;

/**
 *
 * @author Pc
 */
import java.util.Arrays;

class MaxHeap {

    int[] heap;
    int size;
    int capacity;

    MaxHeap(int capacity) {
        this.capacity = capacity;
        heap = new int[capacity];
        size = 0;
    }

    // Insert score into Max Heap
    void insert(int value) {

        if (size == capacity) {
            System.out.println("Heap is full.");
            return;
        }

        heap[size] = value;
        int index = size;
        size++;

        // Move element upward
        while (index > 0) {

            int parent = (index - 1) / 2;

            if (heap[index] > heap[parent]) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    // Return highest score without removing it
    int peek() {

        if (size == 0) {
            return -1;
        }

        return heap[0];
    }

    // Remove and return highest score
    int extractMax() {

        if (size == 0) {
            return -1;
        }

        int max = heap[0];

        heap[0] = heap[size - 1];
        size--;

        if (size > 0) {
            heapify(0);
        }

        return max;
    }

    // Restore Max Heap property
    void heapify(int index) {

        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && heap[left] > heap[largest]) {
            largest = left;
        }

        if (right < size && heap[right] > heap[largest]) {
            largest = right;
        }

        if (largest != index) {
            swap(index, largest);
            heapify(largest);
        }
    }

    // Swap two elements
    void swap(int i, int j) {

        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Display heap array
    void display() {

        System.out.println(Arrays.toString(
                Arrays.copyOf(heap, size)));
    }
}

public class Task2MaxHeap {

    public static void main(String[] args) {

        MaxHeap mh = new MaxHeap(10);

        int[] scores = {65, 92, 78, 85, 99, 70, 88};

        // Insert all quiz scores
        for (int score : scores) {
            mh.insert(score);
        }

        // Display Max Heap
        System.out.println("Max Heap:");
        mh.display();

        // Display highest score
        System.out.println("Highest score: " + mh.peek());

        // Extract Top 3 scores
        System.out.println("\nTop 3 Scores:");

        for (int i = 1; i <= 3; i++) {

            int score = mh.extractMax();

            System.out.println("Rank " + i + ": " + score);
        }

        // Display remaining scores
        System.out.println("\nRemaining scores:");
        mh.display();
    }
}
