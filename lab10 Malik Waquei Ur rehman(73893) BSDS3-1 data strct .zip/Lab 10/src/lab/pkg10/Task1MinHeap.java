/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg10;

/**
 *
 * @author Pc
 */
import java.util.Arrays;

class MinHeap {

    int[] heap;
    int size;
    int capacity;

    MinHeap(int capacity) {
        this.capacity = capacity;
        heap = new int[capacity];
        size = 0;
    }

    // Insert value into Min Heap
    void insert(int value) {

        if (size == capacity) {
            System.out.println("Heap is full.");
            return;
        }

        heap[size] = value;
        int index = size;
        size++;

        // Move element upward
        while (index > 0) {

            int parent = (index - 1) / 2;

            if (heap[index] < heap[parent]) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    // Return smallest element without removing it
    int peek() {

        if (size == 0) {
            return -1;
        }

        return heap[0];
    }

    // Remove and return smallest element
    int extractMin() {

        if (size == 0) {
            return -1;
        }

        int min = heap[0];

        heap[0] = heap[size - 1];
        size--;

        if (size > 0) {
            heapify(0);
        }

        return min;
    }

    // Restore Min Heap property
    void heapify(int index) {

        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && heap[left] < heap[smallest]) {
            smallest = left;
        }

        if (right < size && heap[right] < heap[smallest]) {
            smallest = right;
        }

        if (smallest != index) {
            swap(index, smallest);
            heapify(smallest);
        }
    }

    // Swap two elements
    void swap(int i, int j) {

        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Display heap array
    void display() {

        System.out.println(Arrays.toString(
                Arrays.copyOf(heap, size)));
    }

    // Return number of elements
    int getSize() {
        return size;
    }
}

public class Task1MinHeap {

    public static void main(String[] args) {

        MinHeap mh = new MinHeap(10);

        int[] values = {40, 15, 30, 10, 50, 20, 25};

        // Insert all values
        for (int value : values) {
            mh.insert(value);
        }

        // Display Min Heap
        System.out.println("Min Heap:");
        mh.display();

        // Display smallest element
        System.out.println("Smallest element: " + mh.peek());

        // First deletion
        int removed1 = mh.extractMin();

        System.out.println("\nRemoved: " + removed1);
        System.out.println("Heap after first deletion:");
        mh.display();

        // Second deletion
        int removed2 = mh.extractMin();

        System.out.println("\nRemoved: " + removed2);
        System.out.println("Heap after second deletion:");
        mh.display();

        // Display remaining elements
        System.out.println("\nRemaining elements: " + mh.getSize());
    }
}