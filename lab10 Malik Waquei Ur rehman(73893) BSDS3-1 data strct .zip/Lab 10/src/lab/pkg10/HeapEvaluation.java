/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg10;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Arrays;

class Heap {

    int[] heap;
    int size;
    int capacity;
    boolean isMinHeap;

    // Constructor
    Heap(int capacity, boolean isMinHeap) {
        this.capacity = capacity;
        this.isMinHeap = isMinHeap;
        heap = new int[capacity];
        size = 0;
    }

    // Insert a value
    void insert(int value) {

        if (size == capacity) {
            System.out.println("Heap is full!");
            return;
        }

        heap[size] = value;
        int index = size;
        size++;

        // Heapify Up
        while (index > 0) {

            int parent = (index - 1) / 2;

            if (isMinHeap) {

                if (heap[index] < heap[parent]) {
                    swap(index, parent);
                    index = parent;
                } else {
                    break;
                }

            } else {

                if (heap[index] > heap[parent]) {
                    swap(index, parent);
                    index = parent;
                } else {
                    break;
                }
            }
        }

        System.out.println("Value inserted successfully.");
    }

    // Peek at root element
    int peek() {

        if (size == 0) {
            System.out.println("Heap is empty!");
            return -1;
        }

        return heap[0];
    }

    // Extract root element
    int extract() {

        if (size == 0) {
            System.out.println("Heap is empty!");
            return -1;
        }

        int removed = heap[0];

        heap[0] = heap[size - 1];
        size--;

        // Heapify Down
        if (size > 0) {
            heapifyDown(0);
        }

        return removed;
    }

    // Heapify Down
    void heapifyDown(int index) {

        int left = 2 * index + 1;
        int right = 2 * index + 2;
        int selected = index;

        if (isMinHeap) {

            // Min Heap
            if (left < size &&
                    heap[left] < heap[selected]) {
                selected = left;
            }

            if (right < size &&
                    heap[right] < heap[selected]) {
                selected = right;
            }

        } else {

            // Max Heap
            if (left < size &&
                    heap[left] > heap[selected]) {
                selected = left;
            }

            if (right < size &&
                    heap[right] > heap[selected]) {
                selected = right;
            }
        }

        if (selected != index) {
            swap(index, selected);
            heapifyDown(selected);
        }
    }

    // Swap two elements
    void swap(int i, int j) {

        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Display heap elements
    void display() {

        if (size == 0) {
            System.out.println("Heap is empty!");
            return;
        }

        System.out.println("Heap elements:");

        for (int i = 0; i < size; i++) {
            System.out.print(heap[i] + " ");
        }

        System.out.println();
    }

    // Display current size
    void displaySize() {
        System.out.println("Current Heap Size: " + size);
    }
}

public class HeapEvaluation {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("===== HEAP APPLICATION =====");
        System.out.println("1. Min Heap");
        System.out.println("2. Max Heap");
        System.out.print("Select Heap Type: ");

        int type = sc.nextInt();

        if (type != 1 && type != 2) {
            System.out.println("Invalid Heap Type!");
            sc.close();
            return;
        }

        // Create selected heap
        Heap h;

        if (type == 1) {
            h = new Heap(10, true);
            System.out.println("Min Heap Selected.");
        } else {
            h = new Heap(10, false);
            System.out.println("Max Heap Selected.");
        }

        int choice;

        do {

            System.out.println("\n===== HEAP MENU =====");
            System.out.println("1. Insert");
            System.out.println("2. Peek");
            System.out.println("3. Extract Root");
            System.out.println("4. Display Heap");
            System.out.println("5. Display Size");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Enter value: ");
                    int value = sc.nextInt();

                    h.insert(value);
                    break;

                case 2:

                    int root = h.peek();

                    if (h.size > 0) {
                        if (type == 1) {
                            System.out.println("Minimum Element: " + root);
                        } else {
                            System.out.println("Maximum Element: " + root);
                        }
                    }

                    break;

                case 3:

                    if (h.size > 0) {

                        int removed = h.extract();

                        System.out.println("Removed Element: " + removed);

                    } else {
                        System.out.println("Heap is empty!");
                    }

                    break;

                case 4:

                    h.display();
                    break;

                case 5:

                    h.displaySize();
                    break;

                case 6:

                    System.out.println("Program Ended.");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 6);

        sc.close();
    }
}

