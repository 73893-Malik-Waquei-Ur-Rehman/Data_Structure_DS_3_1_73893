/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg10;

/**
 *
 * @author Pc
 */
class Patient {

    String name;
    int priority;

    Patient(String name, int priority) {
        this.name = name;
        this.priority = priority;
    }

    // Display patient information
    public String toString() {
        return name + " (Priority " + priority + ")";
    }
}

class PatientMinHeap {

    Patient[] heap;
    int size;
    int capacity;

    PatientMinHeap(int capacity) {
        this.capacity = capacity;
        heap = new Patient[capacity];
        size = 0;
    }

    // Insert patient into Min Heap
    void insert(Patient p) {

        if (size == capacity) {
            System.out.println("Queue is full.");
            return;
        }

        heap[size] = p;
        int index = size;
        size++;

        // Move patient upward
        while (index > 0) {

            int parent = (index - 1) / 2;

            if (heap[index].priority < heap[parent].priority) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    // Return most urgent patient
    Patient peek() {

        if (size == 0) {
            return null;
        }

        return heap[0];
    }

    // Remove most urgent patient
    Patient extractMin() {

        if (size == 0) {
            return null;
        }

        Patient min = heap[0];

        heap[0] = heap[size - 1];
        size--;

        if (size > 0) {
            heapify(0);
        }

        return min;
    }

    // Restore Min Heap property
    void heapify(int index) {

        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size &&
                heap[left].priority < heap[smallest].priority) {
            smallest = left;
        }

        if (right < size &&
                heap[right].priority < heap[smallest].priority) {
            smallest = right;
        }

        if (smallest != index) {
            swap(index, smallest);
            heapify(smallest);
        }
    }

    // Swap two patients
    void swap(int i, int j) {

        Patient temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Display waiting patients
    void display() {

        if (size == 0) {
            System.out.println("No patients waiting.");
            return;
        }

        for (int i = 0; i < size; i++) {
            System.out.println(heap[i]);
        }
    }
}

public class Task3HospitalHeap {

    public static void main(String[] args) {

        PatientMinHeap ph = new PatientMinHeap(5);

        // Insert patients
        ph.insert(new Patient("Ali", 3));
        ph.insert(new Patient("Sara", 1));
        ph.insert(new Patient("Bilal", 4));
        ph.insert(new Patient("Ayesha", 2));
        ph.insert(new Patient("Usman", 5));

        // Display next patient
        System.out.println("Next patient to be treated:");
        System.out.println(ph.peek());

        // Treat top 2 patients
        System.out.println("\nTreating patients:");

        for (int i = 1; i <= 2; i++) {

            Patient p = ph.extractMin();

            System.out.println("Patient " + i + ": "
                    + p.name + " - Priority " + p.priority);
        }

        // Display remaining patients
        System.out.println("\nRemaining patients:");
        ph.display();
    }
}