/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */
  import java.util.Arrays;
public class Bonus_Task {
    
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node head = null;

    public static void displayList() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }

        System.out.println("null");
    }

    public static void insertAtBeginning(int mark) {
        Node newNode = new Node(mark);
        newNode.next = head;
        head = newNode;
    }

    public static void deleteMark(int mark) {

        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == mark) {
            head = head.next;
            System.out.println(mark + " deleted from linked list.");
            return;
        }

        Node current = head;

        while (current.next != null && current.next.data != mark) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println(mark + " not found.");
        } else {
            current.next = current.next.next;
            System.out.println(mark + " deleted from linked list.");
        }
    }

    public static void main(String[] args) {

        int[] marks = {78, 65, 92, 55, 88, 73};

        System.out.println("Original Student Marks:");
        System.out.println(Arrays.toString(marks));

        int sum = 0;
        int maximum = marks[0];
        int minimum = marks[0];

        for (int mark : marks) {
            sum += mark;

            if (mark > maximum) {
                maximum = mark;
            }

            if (mark < minimum) {
                minimum = mark;
            }
        }

        double average = (double) sum / marks.length;

        System.out.println("\nMaximum Marks = " + maximum);
        System.out.println("Minimum Marks = " + minimum);
        System.out.println("Average Marks = " + average);

        Arrays.sort(marks);

        System.out.println("\nSorted Marks:");
        System.out.println(Arrays.toString(marks));

        for (int mark : marks) {
            insertAtEnd(mark);
        }

        System.out.println("\nLinked List:");
        displayList();

        int newMark = 85;
        System.out.println("\nInserting " + newMark + " at beginning...");
        insertAtBeginning(newMark);

        System.out.println("Linked List after insertion:");
        displayList();

        int deleteMark = 55;
        System.out.println("\nDeleting " + deleteMark + "...");
        deleteMark(deleteMark);

        System.out.println("Linked List after deletion:");
        displayList();

        System.out.println("\nFinal Array:");
        System.out.println(Arrays.toString(marks));

        System.out.println("\nFinal Linked List:");
        displayList();
    }

    public static void insertAtEnd(int mark) {

        Node newNode = new Node(mark);

        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;

        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
    }
}

