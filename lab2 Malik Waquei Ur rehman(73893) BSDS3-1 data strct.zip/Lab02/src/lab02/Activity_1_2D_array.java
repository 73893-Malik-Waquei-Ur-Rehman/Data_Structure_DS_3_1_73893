/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class Activity_1_2D_array {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter number of columns: ");
        int columns = input.nextInt();
        
        int[][] numbers = new int[rows][columns];
        
        System.out.println("\nEnter the elements:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print("Enter element [" + i + "][" + j + "]: ");
                numbers[i][j] = input.nextInt();
            }
        }
        
        int sum = 0;
        int max = numbers[0][0];
        int min = numbers[0][0];
        
        System.out.println("\n2D Array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {

                System.out.print(numbers[i][j] + "\t");
                
                sum += numbers[i][j];
                
                if (numbers[i][j] > max) {
                    max = numbers[i][j];
                }
                
                if (numbers[i][j] < min) {
                    min = numbers[i][j];
                }
            }
            System.out.println();
        }
        
        int totalElements = rows * columns;
        double average = (double) sum / totalElements;

        System.out.println("\nSum = " + sum);
        System.out.println("Average = " + average);
        System.out.println("Maximum = " + max);
        System.out.println("Minimum = " + min);

        System.out.println("\nSum of Each Row:");
        for (int i = 0; i < rows; i++) {
            int rowSum = 0;

            for (int j = 0; j < columns; j++) {
                rowSum += numbers[i][j];
            }

            System.out.println("Row " + (i + 1) + " = " + rowSum);
        }
        
        System.out.println("\nSum of Each Column:");
        for (int j = 0; j < columns; j++) {
            int columnSum = 0;

            for (int i = 0; i < rows; i++) {
                columnSum += numbers[i][j];
            }
            System.out.println("Column " + (j + 1) + " = " + columnSum);
        }
        input.close();
    }
}
    

