/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */
import java.util.Arrays;
public class Activity_2 {
    public static void bubbleSort(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {

            for (int j = 0; j < arr.length - 1 - i; j++) {

                if (arr[j] > arr[j + 1]) {
                  
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    
    public static void selectionSort(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {

            int minIndex = i;
            
            for (int j = i + 1; j < arr.length; j++) {

                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            
            int temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
    
    public static void insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {

            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
    public static void main(String[] args) {
        int[] original = {64, 25, 12, 22, 11, 90, 34};
        
        int[] bubbleArray = original.clone();
        int[] selectionArray = original.clone();
        int[] insertionArray = original.clone();

        System.out.println("Original Array:");
        System.out.println(Arrays.toString(original));

        bubbleSort(bubbleArray);
        System.out.println("\nBubble Sort:");
        System.out.println(Arrays.toString(bubbleArray));

        selectionSort(selectionArray);
        System.out.println("\nSelection Sort:");
        System.out.println(Arrays.toString(selectionArray));

        insertionSort(insertionArray);
        System.out.println("\nInsertion Sort:");
        System.out.println(Arrays.toString(insertionArray));
    }
}
    
