/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */
public class Activity_1_1D_array {
    public static void main(String[] args) {
        int[] numbers = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};
        
        System.out.println("A. Array Traversal:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        int sum = 0;
        int max = numbers[0];
        int min = numbers[0];

        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];

            if (numbers[i] > max) {
                max = numbers[i];
            }
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }
        double average = (double) sum / numbers.length;

        System.out.println("\n\nB. Statistics:");
        System.out.println("Sum = " + sum);
        System.out.println("Average = " + average);
        System.out.println("Maximum = " + max);
        System.out.println("Minimum = " + min);
        
        int insertIndex = 4;
        int insertValue = 100;

        int[] insertedArray = new int[numbers.length + 1];
        
        for (int i = 0; i < insertIndex; i++) {
            insertedArray[i] = numbers[i];
        }
        insertedArray[insertIndex] = insertValue;

        for (int i = insertIndex; i < numbers.length; i++) {
            insertedArray[i + 1] = numbers[i];
        }
        System.out.println("\nC. After Insertion:");
        for (int i = 0; i < insertedArray.length; i++) {
            System.out.print(insertedArray[i] + " ");
        }
        int deleteIndex = 4;

        int[] deletedArray = new int[insertedArray.length - 1];
        
        for (int i = 0; i < deleteIndex; i++) {
            deletedArray[i] = insertedArray[i];
        }
        for (int i = deleteIndex; i < deletedArray.length; i++) {
            deletedArray[i] = insertedArray[i + 1];
        }
        System.out.println("\n\nD. After Deletion:");
        for (int i = 0; i < deletedArray.length; i++) {
            System.out.print(deletedArray[i] + " ");
        }
    }
}   

    

