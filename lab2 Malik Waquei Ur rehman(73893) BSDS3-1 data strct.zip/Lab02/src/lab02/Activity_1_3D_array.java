/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */
 import java.util.Scanner;
public class Activity_1_3D_array {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter number of layers: ");
        int layers = input.nextInt();
        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter number of columns: ");
        int columns = input.nextInt();
        
        int[][][] numbers = new int[layers][rows][columns];
        
        System.out.println("\nEnter the elements:");
        for (int l = 0; l < layers; l++) {
            System.out.println("Layer " + (l + 1));
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {
                    System.out.print("Enter element [" + l + "][" + r + "][" + c + "]: ");
                    numbers[l][r][c] = input.nextInt();
                }
            }
        }
        
        int sum = 0;
        int max = numbers[0][0][0];
        int min = numbers[0][0][0];
        
        System.out.println("\n3D Array:");
        for (int l = 0; l < layers; l++) {
            System.out.println("Layer " + (l + 1) + ":");
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {
                    System.out.print(numbers[l][r][c] + "\t");
                    
                    sum += numbers[l][r][c];
                    
                    if (numbers[l][r][c] > max) {
                        max = numbers[l][r][c];
                    }
                    
                    if (numbers[l][r][c] < min) {
                        min = numbers[l][r][c];
                    }
                }
                System.out.println();
            }
            System.out.println();
        }
        
        int totalElements = layers * rows * columns;
        double average = (double) sum / totalElements;

        System.out.println("Sum = " + sum);
        System.out.println("Average = " + average);
        System.out.println("Maximum = " + max);
        System.out.println("Minimum = " + min);
        
        System.out.println("\nSum of Each Layer:");
        for (int l = 0; l < layers; l++) {
            int layerSum = 0;
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {

                    layerSum += numbers[l][r][c];
                }
            }
            System.out.println("Layer " + (l + 1) + " = " + layerSum);
        }
        
        System.out.print("\nEnter a value to search: ");
        int searchValue = input.nextInt();
        
        boolean found = false;
        for (int l = 0; l < layers; l++) {
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {
                    
                    if (numbers[l][r][c] == searchValue) {

                        System.out.println(
                            "Value found at Layer " + (l + 1)
                            + ", Row " + (r + 1)
                            + ", Column " + (c + 1)
                        );
                        found = true;
                    }
                }
            }
        }
        if (!found) {
            System.out.println("Value not found in the 3D array.");
        }
        input.close();
    }
}
    

