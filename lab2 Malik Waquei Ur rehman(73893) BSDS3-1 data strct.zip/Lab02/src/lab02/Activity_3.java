/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab02;

/**
 *
 * @author Pc
 */

    import java.util.Scanner;
public class Activity_3 {
    
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node head = null;
    
    public static void display() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }

        System.out.println("null");
    }
    
    public static void insertAtBeginning(int data) {
        Node newNode = new Node(data);

        newNode.next = head;
        head = newNode;
    }

    public static void insertAtEnd(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;

        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public static boolean search(int value) {
        Node current = head;

        while (current != null) {
            if (current.data == value) {
                return true;
            }

            current = current.next;
        }

        return false;
    }

    public static void delete(int value) {

        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == value) {
            head = head.next;
            System.out.println(value + " deleted successfully.");
            return;
        }

        Node current = head;

        while (current.next != null && current.next.data != value) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println(value + " not found in the list.");
            return;
        }

        current.next = current.next.next;

        System.out.println(value + " deleted successfully.");
    }
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Node node1 = new Node(10);
        Node node2 = new Node(20);
        Node node3 = new Node(30);
        Node node4 = new Node(40);
        Node node5 = new Node(50);

        head = node1;
        node1.next = node2;
        node2.next = node3;
        node3.next = node4;
        node4.next = node5;

        System.out.println("Initial Linked List:");
        display();

        System.out.print("\nEnter value to insert at beginning: ");
        int beginningValue = input.nextInt();

        insertAtBeginning(beginningValue);

        System.out.println("After insertion at beginning:");
        display();

        System.out.print("\nEnter value to insert at end: ");
        int endValue = input.nextInt();

        insertAtEnd(endValue);

        System.out.println("After insertion at end:");
        display();

        System.out.print("\nEnter value to search: ");
        int searchValue = input.nextInt();

        if (search(searchValue)) {
            System.out.println(searchValue + " found in the list.");
        } else {
            System.out.println(searchValue + " not found in the list.");
        }

        System.out.print("\nEnter value to delete: ");
        int deleteValue = input.nextInt();

        delete(deleteValue);

        System.out.println("\nFinal Linked List:");
        display();

        input.close();
    }
}

