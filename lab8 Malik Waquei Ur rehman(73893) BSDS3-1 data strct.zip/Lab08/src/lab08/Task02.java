/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab08;

/**
 *
 * @author Pc
 */


class Node {
    int data;
    Node left, right;

    Node(int value) {
        data = value;
        left = right = null;
    }
}

public class Task02 {
    Node root;

    // Insert a value into the BST
    Node insert(Node root, int value) {
        if (root == null) {
            return new Node(value);
        }

        if (value < root.data) {
            root.left = insert(root.left, value);
        } else if (value > root.data) {
            root.right = insert(root.right, value);
        }

        return root;
    }

    // Search for a value in the BST
    boolean search(Node root, int value) {
        if (root == null) {
            return false;
        }

        if (root.data == value) {
            return true;
        }

        if (value < root.data) {
            return search(root.left, value);
        } else {
            return search(root.right, value);
        }
    }

    // Find the smallest value in a subtree
    Node findMinNode(Node root) {
        while (root.left != null) {
            root = root.left;
        }
        return root;
    }

    // Delete a value from the BST
    Node delete(Node root, int value) {
        if (root == null) {
            return null;
        }

        if (value < root.data) {
            root.left = delete(root.left, value);
        } else if (value > root.data) {
            root.right = delete(root.right, value);
        } else {

            // Case 1: Node has no children
            if (root.left == null && root.right == null) {
                return null;
            }

            // Case 2: Node has only a right child
            if (root.left == null) {
                return root.right;
            }

            // Case 2: Node has only a left child
            if (root.right == null) {
                return root.left;
            }

            // Case 3: Node has two children
            // Replace it with its inorder successor
            Node successor = findMinNode(root.right);
            root.data = successor.data;

            // Delete the original successor node
            root.right = delete(root.right, successor.data);
        }

        return root;
    }

    // Display inorder traversal
    void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    public static void main(String[] args) {
        Task02 tree = new Task02();

        // Construct the original BST
        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};

        for (int value : values) {
            tree.root = tree.insert(tree.root, value);
        }

        // Task 2.1: Search for 35
        System.out.println("Search for 35:");
        if (tree.search(tree.root, 35)) {
            System.out.println("35 was found in the BST.");
        } else {
            System.out.println("35 was not found.");
        }

        // Task 2.2: Search for 100
        System.out.println("\nSearch for 100:");
        if (tree.search(tree.root, 100)) {
            System.out.println("100 was found in the BST.");
        } else {
            System.out.println("100 was not found in the BST.");
        }

        // Task 2.3: Delete leaf node 10
        tree.root = tree.delete(tree.root, 10);
        System.out.println("\nAfter deleting leaf node 10:");
        tree.inorder(tree.root);
        System.out.println();

        // Task 2.4: Delete node 25
        // Note: 25 has TWO children in this BST.
        tree.root = tree.delete(tree.root, 25);
        System.out.println("\nAfter deleting node 25:");
        tree.inorder(tree.root);
        System.out.println();

        // Task 2.5: Delete root node 45
        tree.root = tree.delete(tree.root, 45);
        System.out.println("\nAfter deleting root node 45:");
        tree.inorder(tree.root);
        System.out.println();
    }
}
    

