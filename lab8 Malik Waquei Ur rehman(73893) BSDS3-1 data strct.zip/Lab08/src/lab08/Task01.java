/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab08;

/**
 *
 * @author Pc
 */
    class Node {
    int data;
    Node left, right;

    Node(int value) {
        data = value;
        left = right = null;
    }
}
public class Task01 {

    Node root;

    // Insert a value into the BST
    Node insert(Node root, int value) {
        if (root == null) {
            return new Node(value);
        }

        if (value < root.data) {
            root.left = insert(root.left, value);
        } else if (value > root.data) {
            root.right = insert(root.right, value);
        }

        return root;
    }

    // Inorder: Left, Root, Right
    void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    // Preorder: Root, Left, Right
    void preorder(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    // Postorder: Left, Right, Root
    void postorder(Node root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    // Find minimum value
    int findMin(Node root) {
        while (root.left != null) {
            root = root.left;
        }
        return root.data;
    }

    // Find maximum value
    int findMax(Node root) {
        while (root.right != null) {
            root = root.right;
        }
        return root.data;
    }

    public static void main(String[] args) {
        Task01 tree = new Task01();

        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};

        // Construct the BST
        for (int value : values) {
            tree.root = tree.insert(tree.root, value);
        }

        System.out.println("Inorder Traversal:");
        tree.inorder(tree.root);

        System.out.println("\n\nPreorder Traversal:");
        tree.preorder(tree.root);

        System.out.println("\n\nPostorder Traversal:");
        tree.postorder(tree.root);

        System.out.println("\n\nMinimum Value: " + tree.findMin(tree.root));
        System.out.println("Maximum Value: " + tree.findMax(tree.root));
    }
}