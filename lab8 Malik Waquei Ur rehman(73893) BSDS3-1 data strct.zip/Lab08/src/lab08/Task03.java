/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab08;

/**
 *
 * @author Pc
 */

import java.util.Scanner;

class Node {
    int studentID;
    String studentName;

    Node left, right;

    // Constructor
    Node(int id, String name) {
        studentID = id;
        studentName = name;
        left = right = null;
    }
}

public class Task03 {
    Node root;
    Scanner input = new Scanner(System.in);

    // 1. Insert a new student
    Node insert(Node root, int id, String name) {

        if (root == null) {
            return new Node(id, name);
        }

        if (id < root.studentID) {
            root.left = insert(root.left, id, name);
        } 
        else if (id > root.studentID) {
            root.right = insert(root.right, id, name);
        } 
        else {
            System.out.println("Student ID already exists!");
        }

        return root;
    }

    // 2. Search for a student
    Node search(Node root, int id) {

        if (root == null || root.studentID == id) {
            return root;
        }

        if (id < root.studentID) {
            return search(root.left, id);
        } 
        else {
            return search(root.right, id);
        }
    }

    // Find minimum node
    Node findMin(Node root) {

        while (root.left != null) {
            root = root.left;
        }

        return root;
    }

    // 3. Delete a student
    Node delete(Node root, int id) {

        if (root == null) {
            return null;
        }

        if (id < root.studentID) {
            root.left = delete(root.left, id);
        } 
        else if (id > root.studentID) {
            root.right = delete(root.right, id);
        } 
        else {

            // Case 1: No child
            if (root.left == null && root.right == null) {
                return null;
            }

            // Case 2: Only right child
            if (root.left == null) {
                return root.right;
            }

            // Case 2: Only left child
            if (root.right == null) {
                return root.left;
            }

            // Case 3: Two children
            Node successor = findMin(root.right);

            root.studentID = successor.studentID;
            root.studentName = successor.studentName;

            root.right = delete(root.right, successor.studentID);
        }

        return root;
    }

    // 4. Display students in ascending order
    void display(Node root) {

        if (root != null) {

            display(root.left);

            System.out.println("Student ID: " + root.studentID);
            System.out.println("Student Name: " + root.studentName);
            System.out.println("----------------------");

            display(root.right);
        }
    }

    // 5. Count total students
    int countStudents(Node root) {

        if (root == null) {
            return 0;
        }

        return 1 + countStudents(root.left)
                 + countStudents(root.right);
    }

    // Main menu
    public static void main(String[] args) {

        Task03 tree = new Task03();

        int choice;

        do {

            System.out.println("\n===== STUDENT RECORD MANAGEMENT =====");
            System.out.println("1. Insert Student");
            System.out.println("2. Search Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Display All Students");
            System.out.println("5. Count Total Students");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            choice = tree.input.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = tree.input.nextInt();

                    tree.input.nextLine();

                    System.out.print("Enter Student Name: ");
                    String name = tree.input.nextLine();

                    if (tree.search(tree.root, id) != null) {
                        System.out.println("Student ID already exists!");
                    } else {
                        tree.root = tree.insert(tree.root, id, name);
                        System.out.println("Student inserted successfully!");
                    }
                    break;

                case 2:
                    System.out.print("Enter Student ID to search: ");
                    id = tree.input.nextInt();

                    Node found = tree.search(tree.root, id);

                    if (found != null) {
                        System.out.println("Student Found!");
                        System.out.println("Student ID: " + found.studentID);
                        System.out.println("Student Name: " + found.studentName);
                    } else {
                        System.out.println("Student not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter Student ID to delete: ");
                    id = tree.input.nextInt();

                    if (tree.search(tree.root, id) != null) {
                        tree.root = tree.delete(tree.root, id);
                        System.out.println("Student deleted successfully!");
                    } else {
                        System.out.println("Student not found!");
                    }
                    break;

                case 4:
                    if (tree.root == null) {
                        System.out.println("No student records available.");
                    } else {
                        System.out.println("\nStudent Records (Ascending Order):");
                        tree.display(tree.root);
                    }
                    break;

                case 5:
                    System.out.println("Total Students: "
                            + tree.countStudents(tree.root));
                    break;

                case 6:
                    System.out.println("Program exited successfully.");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 6);
    }
}
