/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab08;

/**
 *
 * @author Pc
 */

import java.util.Scanner;

public class Evaluation_Task {

    // Node class
    static class Node {
        int data;
        Node left, right;

        Node(int value) {
            data = value;
            left = right = null;
        }
    }

    // Root node of BST
    static Node root = null;

    // Insert a new value
    static Node insert(Node root, int value) {

        if (root == null) {
            return new Node(value);
        }

        if (value < root.data) {
            root.left = insert(root.left, value);
        }
        else if (value > root.data) {
            root.right = insert(root.right, value);
        }
        else {
            System.out.println("Duplicate value not allowed!");
        }

        return root;
    }

    // Search a value
    static boolean search(Node root, int value) {

        if (root == null) {
            return false;
        }

        if (root.data == value) {
            return true;
        }

        if (value < root.data) {
            return search(root.left, value);
        }
        else {
            return search(root.right, value);
        }
    }

    // Inorder Traversal (Left, Root, Right)
    static void inorder(Node root) {

        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    // Preorder Traversal (Root, Left, Right)
    static void preorder(Node root) {

        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    // Postorder Traversal (Left, Right, Root)
    static void postorder(Node root) {

        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    // Find minimum value
    static int findMin(Node root) {

        while (root.left != null) {
            root = root.left;
        }

        return root.data;
    }

    // Find maximum value
    static int findMax(Node root) {

        while (root.right != null) {
            root = root.right;
        }

        return root.data;
    }

    // Delete a node
    static Node delete(Node root, int value) {

        if (root == null) {
            return null;
        }

        if (value < root.data) {
            root.left = delete(root.left, value);
        }
        else if (value > root.data) {
            root.right = delete(root.right, value);
        }
        else {

            // Case 1: Node has no child
            if (root.left == null && root.right == null) {
                return null;
            }

            // Case 2: Node has one child
            if (root.left == null) {
                return root.right;
            }

            if (root.right == null) {
                return root.left;
            }

            // Case 3: Node has two children
            int minValue = findMin(root.right);

            root.data = minValue;

            root.right = delete(root.right, minValue);
        }

        return root;
    }

    // Main method
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int choice, value;

        do {

            System.out.println("\n===== BINARY SEARCH TREE MENU =====");
            System.out.println("1. Insert Multiple Values");
            System.out.println("2. Search Value");
            System.out.println("3. Inorder Traversal");
            System.out.println("4. Preorder Traversal");
            System.out.println("5. Postorder Traversal");
            System.out.println("6. Find Minimum Value");
            System.out.println("7. Find Maximum Value");
            System.out.println("8. Delete Node");
            System.out.println("9. Display Updated BST (Inorder)");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("How many values do you want to insert? ");
                    int n = input.nextInt();

                    for (int i = 0; i < n; i++) {
                        System.out.print("Enter value: ");
                        value = input.nextInt();
                        root = insert(root, value);
                    }
                    break;

                case 2:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Enter value to search: ");
                        value = input.nextInt();

                        if (search(root, value)) {
                            System.out.println("Value found in BST.");
                        } else {
                            System.out.println("Value not found.");
                        }
                    }
                    break;

                case 3:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Inorder: ");
                        inorder(root);
                        System.out.println();
                    }
                    break;

                case 4:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Preorder: ");
                        preorder(root);
                        System.out.println();
                    }
                    break;

                case 5:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Postorder: ");
                        postorder(root);
                        System.out.println();
                    }
                    break;

                case 6:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.println("Minimum value: " + findMin(root));
                    }
                    break;

                case 7:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.println("Maximum value: " + findMax(root));
                    }
                    break;

                case 8:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Enter value to delete: ");
                        value = input.nextInt();

                        if (search(root, value)) {
                            root = delete(root, value);
                            System.out.println("Node deleted successfully.");
                        } else {
                            System.out.println("Value not found in BST.");
                        }
                    }
                    break;

                case 9:
                    if (root == null) {
                        System.out.println("Tree is empty!");
                    } else {
                        System.out.print("Updated BST (Inorder): ");
                        inorder(root);
                        System.out.println();
                    }
                    break;

                case 0:
                    System.out.println("Program terminated.");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 0);

        input.close();
    }
}

    

