/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg03;

/**
 *
 * @author Pc
 */


public class Activity_2_quick_sort {
    // Partition method
    static int partition(int[] arr, int low, int high) {
        // Last element is selected as pivot
        int pivot = arr[high];

        int i = low - 1;

        System.out.println("Pivot = " + pivot);
        // Compare elements with pivot
        for (int j = low; j < high; j++) {

            if (arr[j] <= pivot) {
                i++;
                // Swap elements
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;

                System.out.println("After swap:");
                printArray(arr);
            }
        }
        // Final pivot swap
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        System.out.println("After final pivot swap:");
        printArray(arr);

        return i + 1;
    }
    // Quick Sort method
    static void quickSort(int[] arr, int low, int high) {

        if (low < high) {

            int pivotIndex = partition(arr, low, high);
            // Sort left side
            quickSort(arr, low, pivotIndex - 1);
            // Sort right side
            quickSort(arr, pivotIndex + 1, high);
        }
    }
    // Display array
    static void printArray(int[] arr) {

        for (int value : arr) {
            System.out.print(value + " ");
        }

        System.out.println();
    }

    public static void main(String[] args) {

        int[] arr = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("Original Array:");
        printArray(arr);

        System.out.println("\nQuick Sort Trace:");

        quickSort(arr, 0, arr.length - 1);

        System.out.println("\nSorted Array:");
        printArray(arr);
    }
}

