/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab.pkg03;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
public class Activity_1_Factorial {
    
    static int factorial(int n) {
        
        if (n == 0) {
            return 1;
        }
        
        return n * factorial(n - 1);
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int n = input.nextInt();

        int result = factorial(n);

        System.out.println("Factorial of " + n + " = " + result);
    }
}