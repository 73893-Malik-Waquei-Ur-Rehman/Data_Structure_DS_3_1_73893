/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg03;

/**
 *
 * @author Pc
 */


public class Activity_1_structural_Array {
    // 1. Recursive Traversal
    static void traverse(int[] arr, int index) {
        if (index == arr.length) {
            return;
        }

        System.out.println(arr[index]);
        traverse(arr, index + 1);
    }

    // 2. Recursive Sum
    static int sum(int[] arr, int index) {
        if (index == arr.length) {
            return 0;
        }

        return arr[index] + sum(arr, index + 1);
    }

    // 3. Recursive Search
    static int search(int[] arr, int index, int target) {
        if (index == arr.length) {
            return -1;
        }

        if (arr[index] == target) {
            return index;
        }

        return search(arr, index + 1, target);
    }

    public static void main(String[] args) {

        int[] arr = {12, 45, 7, 23, 56, 89, 34};

        // Traversal
        System.out.println("Array Elements:");
        traverse(arr, 0);

        // Sum
        int total = sum(arr, 0);
        System.out.println("Sum = " + total);

        // Search
        int target = 23;
        int index = search(arr, 0, target);

        System.out.println("Target = " + target);
        System.out.println("Index = " + index);
    }
}

