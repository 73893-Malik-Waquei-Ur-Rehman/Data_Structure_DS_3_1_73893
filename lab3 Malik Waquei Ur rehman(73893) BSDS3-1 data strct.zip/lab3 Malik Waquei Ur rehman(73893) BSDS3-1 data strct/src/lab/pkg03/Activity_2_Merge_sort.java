/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg03;

/**
 *
 * @author Pc
 */


public class Activity_2_Merge_sort {
    static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        // Temporary arrays
        int[] L = new int[n1];
        int[] R = new int[n2];
        // Copy data into L
        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }
        // Copy data into R
        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }
        int i = 0;
        int j = 0;
        int k = left;
        // Compare elements and merge
        while (i < n1 && j < n2) {

            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }

            k++;
        }
        // Copy remaining elements from L
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }
        // Copy remaining elements from R
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
    static void mergeSort(int[] arr, int left, int right) {

        if (left < right) {
            // Find midpoint
            int mid = left + (right - left) / 2;
            // Divide left half
            mergeSort(arr, left, mid);
            // Divide right half
            mergeSort(arr, mid + 1, right);
            // Merge sorted halves
            merge(arr, left, mid, right);
        }
    }
    public static void main(String[] args) {

        int[] arr = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("Array before Merge Sort:");

        for (int num : arr) {
            System.out.print(num + " ");
        }
        mergeSort(arr, 0, arr.length - 1);

        System.out.println("\n\nArray after Merge Sort:");

        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
