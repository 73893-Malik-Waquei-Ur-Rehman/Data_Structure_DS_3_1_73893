/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab.pkg09;

/**
 *
 * @author Pc
 */
public class Task1LinearProbing {

    static int SIZE = 7;
    static int[] table = new int[SIZE];
    static int collisions = 0;

    // Insert key using Linear Probing
    static void insert(int key) {

        int index = key % SIZE;

        // Check for collision
        while (table[index] != 0) {
            collisions++;
            index = (index + 1) % SIZE;
        }

        table[index] = key;
    }

    // Search for a key
    static boolean search(int key) {

        int index = key % SIZE;

        for (int i = 0; i < SIZE; i++) {

            if (table[index] == key) {
                return true;
            }

            // If empty, key does not exist
            if (table[index] == 0) {
                return false;
            }

            index = (index + 1) % SIZE;
        }

        return false;
    }

    // Display hash table
    static void display() {
        System.out.println("Hash Table:");

        for (int i = 0; i < SIZE; i++) {
            System.out.println("Index " + i + ": " + table[i]);
        }
    }

    public static void main(String[] args) {

        int[] keys = {14, 21, 8, 15, 22};

        // Insert keys
        for (int key : keys) {
            insert(key);
        }

        // Display table
        display();

        // Display collisions
        System.out.println("Total Collisions: " + collisions);

        // Search keys
        System.out.println("Search 15: " + search(15));
        System.out.println("Search 99: " + search(99));
    }
}

    

