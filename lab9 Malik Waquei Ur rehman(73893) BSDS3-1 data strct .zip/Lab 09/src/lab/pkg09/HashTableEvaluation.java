/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg09;

/**
 *
 * @author Pc
 */

import java.util.Scanner;

class Entry {
    int key;
    String value;
    boolean isDeleted;

    Entry(int key, String value) {
        this.key = key;
        this.value = value;
        this.isDeleted = false;
    }
}

class HashTable {

    private Entry[] table;
    private int size;
    private int method; // 1 = Linear, 2 = Quadratic, 3 = Double Hashing

    HashTable(int size, int method) {
        this.size = size;
        this.method = method;
        table = new Entry[size];
    }

    // First hash function
    private int h1(int key) {
        return Math.floorMod(key, size);
    }

    // Second hash function for Double Hashing
    private int h2(int key) {
        return 7 - Math.floorMod(key, 7);
    }

    // Calculate index according to selected method
    private int getIndex(int key, int i) {

        int index;

        if (method == 1) {
            // Linear Probing
            index = (h1(key) + i) % size;
        }
        else if (method == 2) {
            // Quadratic Probing
            index = (h1(key) + i * i) % size;
        }
        else {
            // Double Hashing
            index = (h1(key) + i * h2(key)) % size;
        }

        return index;
    }

    // Insert key and value
    public void insert(int key, String value) {

        int firstDeleted = -1;

        for (int i = 0; i < size; i++) {

            int index = getIndex(key, i);

            // If slot is empty
            if (table[index] == null) {

                // Use earlier tombstone if available
                if (firstDeleted != -1) {
                    index = firstDeleted;
                }

                table[index] = new Entry(key, value);
                System.out.println("Record inserted successfully.");
                return;
            }

            // If slot is deleted, remember it
            if (table[index].isDeleted) {

                if (firstDeleted == -1) {
                    firstDeleted = index;
                }
            }
            else if (table[index].key == key) {

                // Update existing key
                table[index].value = value;
                System.out.println("Key already exists. Value updated.");
                return;
            }
        }

        // If no empty slot but a tombstone exists
        if (firstDeleted != -1) {
            table[firstDeleted] = new Entry(key, value);
            System.out.println("Record inserted successfully.");
        }
        else {
            System.out.println("Hash table is full.");
        }
    }

    // Search for a key
    public String search(int key) {

        for (int i = 0; i < size; i++) {

            int index = getIndex(key, i);

            // Empty slot means key does not exist
            if (table[index] == null) {
                return null;
            }

            // Ignore deleted slots
            if (!table[index].isDeleted && table[index].key == key) {
                return table[index].value;
            }
        }

        return null;
    }

    // Delete a key using tombstone
    public void delete(int key) {

        for (int i = 0; i < size; i++) {

            int index = getIndex(key, i);

            // Stop if slot is empty
            if (table[index] == null) {
                System.out.println("Key not found.");
                return;
            }

            // Find key and mark as deleted
            if (!table[index].isDeleted && table[index].key == key) {

                table[index].isDeleted = true;
                System.out.println("Key deleted using tombstone.");
                return;
            }
        }

        System.out.println("Key not found.");
    }

    // Display hash table
    public void display() {

        System.out.println("\nHash Table:");

        for (int i = 0; i < size; i++) {

            System.out.print("Index " + i + ": ");

            if (table[i] == null) {
                System.out.println("Empty");
            }
            else if (table[i].isDeleted) {
                System.out.println("Deleted (Tombstone)");
            }
            else {
                System.out.println(table[i].key + " -> " + table[i].value);
            }
        }
    }
}

public class HashTableEvaluation {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        HashTable ht = null;
        int choice;

        do {

            System.out.println("\n===== HASH TABLE MENU =====");
            System.out.println("1. Select Probing Method / Create Table");
            System.out.println("2. Insert");
            System.out.println("3. Search");
            System.out.println("4. Delete");
            System.out.println("5. Display");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.println("\nSelect Probing Method:");
                    System.out.println("1. Linear Probing");
                    System.out.println("2. Quadratic Probing");
                    System.out.println("3. Double Hashing");
                    System.out.print("Enter method: ");

                    int method = sc.nextInt();

                    if (method >= 1 && method <= 3) {
                        ht = new HashTable(11, method);
                        System.out.println("Hash table created with size 11.");
                    }
                    else {
                        System.out.println("Invalid method.");
                    }

                    break;

                case 2:

                    if (ht == null) {
                        System.out.println("Create a hash table first.");
                        break;
                    }

                    System.out.print("Enter integer key: ");
                    int key = sc.nextInt();

                    sc.nextLine(); // Clear input buffer

                    System.out.print("Enter string value: ");
                    String value = sc.nextLine();

                    ht.insert(key, value);

                    break;

                case 3:

                    if (ht == null) {
                        System.out.println("Create a hash table first.");
                        break;
                    }

                    System.out.print("Enter key to search: ");
                    key = sc.nextInt();

                    String result = ht.search(key);

                    if (result != null) {
                        System.out.println("Key found. Value: " + result);
                    }
                    else {
                        System.out.println("Key not found.");
                    }

                    break;

                case 4:

                    if (ht == null) {
                        System.out.println("Create a hash table first.");
                        break;
                    }

                    System.out.print("Enter key to delete: ");
                    key = sc.nextInt();

                    ht.delete(key);

                    break;

                case 5:

                    if (ht == null) {
                        System.out.println("Create a hash table first.");
                        break;
                    }

                    ht.display();

                    break;

                case 6:

                    System.out.println("Program ended.");
                    break;

                default:

                    System.out.println("Invalid choice.");
            }

        } while (choice != 6);

        sc.close();
    }
}
