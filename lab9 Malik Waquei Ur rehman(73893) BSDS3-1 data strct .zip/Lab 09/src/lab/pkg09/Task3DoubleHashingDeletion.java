/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg09;

/**
 *
 * @author Pc
 */

public class Task3DoubleHashingDeletion {

    static int SIZE = 7;

    static int[] keys = new int[SIZE];
    static String[] names = new String[SIZE];
    static boolean[] isDeleted = new boolean[SIZE];
    static boolean[] occupied = new boolean[SIZE];

    // First hash function
    static int h1(int key) {
        return key % SIZE;
    }

    // Second hash function
    static int h2(int key) {
        return 5 - (key % 5);
    }

    // Insert key and name
    static void insert(int key, String name) {

        int index = h1(key);
        int step = h2(key);

        for (int i = 0; i < SIZE; i++) {

            index = (h1(key) + i * step) % SIZE;

            // Insert in empty or deleted slot
            if (!occupied[index] || isDeleted[index]) {

                keys[index] = key;
                names[index] = name;
                occupied[index] = true;
                isDeleted[index] = false;

                return;
            }
        }

        System.out.println("Hash table is full!");
    }

    // Search for key
    static int search(int key) {

        int step = h2(key);

        for (int i = 0; i < SIZE; i++) {

            int index = (h1(key) + i * step) % SIZE;

            // Stop if slot was never occupied
            if (!occupied[index]) {
                return -1;
            }

            // Check key only if not deleted
            if (!isDeleted[index] && keys[index] == key) {
                return index;
            }
        }

        return -1;
    }

    // Delete using tombstone
    static void delete(int key) {

        int index = search(key);

        if (index != -1) {
            isDeleted[index] = true;
            System.out.println("Key " + key + " deleted.");
        } else {
            System.out.println("Key " + key + " not found.");
        }
    }

    // Display table
    static void display() {

        System.out.println("Hash Table:");

        for (int i = 0; i < SIZE; i++) {

            if (!occupied[i]) {
                System.out.println("Index " + i + ": Empty");
            }
            else if (isDeleted[i]) {
                System.out.println("Index " + i + ": Deleted (Tombstone)");
            }
            else {
                System.out.println("Index " + i + ": "
                        + keys[i] + " - " + names[i]);
            }
        }
    }

    public static void main(String[] args) {

        // Insert records
        insert(12, "Ali");
        insert(19, "Sara");
        insert(26, "Bilal");
        insert(5, "Hina");

        // Display before deletion
        System.out.println("Before Deletion:");
        display();

        // Delete key 19
        delete(19);

        // Display after deletion
        System.out.println("\nAfter Deletion:");
        display();

        // Search for key 26
        int result = search(26);

        if (result != -1) {
            System.out.println("\nKey 26 found: " + names[result]);
        } else {
            System.out.println("\nKey 26 not found.");
        }
    }
}

