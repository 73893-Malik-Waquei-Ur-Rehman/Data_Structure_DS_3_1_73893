/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg09;

/**
 *
 * @author Pc
 */

public class Task2ProbingComparison {

    static int SIZE = 11;

    // Quadratic Probing
    static void quadraticProbing(int[] table, int key) {

        int h1 = key % SIZE;

        for (int i = 0; i < SIZE; i++) {

            int index = (h1 + i * i) % SIZE;

            if (table[index] == 0) {
                table[index] = key;
                return;
            }
        }

        System.out.println("Table is full for key " + key);
    }

    // Double Hashing
    static void doubleHashing(int[] table, int key) {

        int h1 = key % SIZE;
        int h2 = 7 - (key % 7);

        for (int i = 0; i < SIZE; i++) {

            int index = (h1 + i * h2) % SIZE;

            if (table[index] == 0) {
                table[index] = key;
                return;
            }
        }

        System.out.println("Table is full for key " + key);
    }

    // Display table
    static void display(int[] table) {

        for (int i = 0; i < SIZE; i++) {
            System.out.println("Index " + i + ": " + table[i]);
        }
    }

    public static void main(String[] args) {

        int[] keys = {22, 33, 44, 11, 55};

        int[] quadraticTable = new int[SIZE];
        int[] doubleHashTable = new int[SIZE];

        // Insert using Quadratic Probing
        for (int key : keys) {
            quadraticProbing(quadraticTable, key);
        }

        // Insert using Double Hashing
        for (int key : keys) {
            doubleHashing(doubleHashTable, key);
        }

        // Display Quadratic Probing table
        System.out.println("Quadratic Probing Table:");
        display(quadraticTable);

        // Display Double Hashing table
        System.out.println("\nDouble Hashing Table:");
        display(doubleHashTable);
    }
}

