/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab05;

/**
 *
 * @author Pc
 */


import java.util.Scanner;
import java.util.Stack;

public class Activity03 {

    // =====================================================
    // CIRCULAR QUEUE
    // =====================================================

    static class CircularQueue {

        int[] queue = new int[5];
        int front = -1;
        int rear = -1;

        boolean isEmpty() {
            return front == -1;
        }

        boolean isFull() {
            return (rear + 1) % queue.length == front;
        }

        void enqueue(int value) {

            if (isFull()) {
                System.out.println("Queue Overflow!");
                return;
            }

            if (isEmpty()) {
                front = 0;
            }

            rear = (rear + 1) % queue.length;
            queue[rear] = value;

            System.out.println(value + " inserted.");
        }

        void dequeue() {

            if (isEmpty()) {
                System.out.println("Queue Underflow!");
                return;
            }

            System.out.println(queue[front] + " removed.");

            if (front == rear) {
                front = -1;
                rear = -1;
            } else {
                front = (front + 1) % queue.length;
            }
        }

        void peek() {

            if (isEmpty()) {
                System.out.println("Queue is empty.");
            } else {
                System.out.println("Front element: " + queue[front]);
            }
        }

        void display() {

            if (isEmpty()) {
                System.out.println("Queue is empty.");
                return;
            }

            System.out.print("Queue: ");

            int i = front;

            while (true) {
                System.out.print(queue[i] + " ");

                if (i == rear) {
                    break;
                }

                i = (i + 1) % queue.length;
            }

            System.out.println();
        }
    }


    // =====================================================
    // PRIORITY QUEUE
    // =====================================================

    static class PriorityQueue {

        int[] value = new int[5];
        int[] priority = new int[5];
        int size = 0;

        void insert(int val, int pri) {

            if (size == 5) {
                System.out.println("Priority Queue Overflow!");
                return;
            }

            value[size] = val;
            priority[size] = pri;
            size++;

            System.out.println("Inserted: " + val +
                    " with priority " + pri);
        }

        void remove() {

            if (size == 0) {
                System.out.println("Priority Queue Underflow!");
                return;
            }

            int highest = 0;

            // Smaller number = higher priority
            for (int i = 1; i < size; i++) {

                if (priority[i] < priority[highest]) {
                    highest = i;
                }
            }

            System.out.println("Removed: " + value[highest] +
                    " with priority " + priority[highest]);

            // Shift elements
            for (int i = highest; i < size - 1; i++) {

                value[i] = value[i + 1];
                priority[i] = priority[i + 1];
            }

            size--;
        }

        void display() {

            if (size == 0) {
                System.out.println("Priority Queue is empty.");
                return;
            }

            System.out.println("Priority Queue:");

            for (int i = 0; i < size; i++) {

                System.out.println(
                        "Value: " + value[i] +
                        "  Priority: " + priority[i]
                );
            }
        }
    }


    // =====================================================
    // DEQUE
    // =====================================================

    static class Deque {

        int[] deque = new int[5];
        int front = -1;
        int rear = -1;

        boolean isFull() {

            return (front == 0 && rear == deque.length - 1)
                    || (front == rear + 1);
        }

        boolean isEmpty() {
            return front == -1;
        }

        void insertFront(int value) {

            if (isFull()) {
                System.out.println("Deque Overflow!");
                return;
            }

            if (isEmpty()) {
                front = 0;
                rear = 0;
            }
            else if (front == 0) {
                front = deque.length - 1;
            }
            else {
                front--;
            }

            deque[front] = value;

            System.out.println(value +
                    " inserted at front.");
        }

        void insertRear(int value) {

            if (isFull()) {
                System.out.println("Deque Overflow!");
                return;
            }

            if (isEmpty()) {
                front = 0;
                rear = 0;
            }
            else if (rear == deque.length - 1) {
                rear = 0;
            }
            else {
                rear++;
            }

            deque[rear] = value;

            System.out.println(value +
                    " inserted at rear.");
        }

        void deleteFront() {

            if (isEmpty()) {
                System.out.println("Deque Underflow!");
                return;
            }

            System.out.println(deque[front] +
                    " deleted from front.");

            if (front == rear) {
                front = -1;
                rear = -1;
            }
            else if (front == deque.length - 1) {
                front = 0;
            }
            else {
                front++;
            }
        }

        void deleteRear() {

            if (isEmpty()) {
                System.out.println("Deque Underflow!");
                return;
            }

            System.out.println(deque[rear] +
                    " deleted from rear.");

            if (front == rear) {
                front = -1;
                rear = -1;
            }
            else if (rear == 0) {
                rear = deque.length - 1;
            }
            else {
                rear--;
            }
        }

        void display() {

            if (isEmpty()) {
                System.out.println("Deque is empty.");
                return;
            }

            System.out.print("Deque: ");

            int i = front;

            while (true) {

                System.out.print(deque[i] + " ");

                if (i == rear) {
                    break;
                }

                i = (i + 1) % deque.length;
            }

            System.out.println();
        }
    }


    // =====================================================
    // INFIX TO POSTFIX
    // =====================================================

    static int precedence(char operator) {

        if (operator == '+' || operator == '-') {
            return 1;
        }

        if (operator == '*' ||
            operator == '/' ||
            operator == '%') {
            return 2;
        }

        return 0;
    }

    static boolean isOperator(char ch) {

        return ch == '+' ||
               ch == '-' ||
               ch == '*' ||
               ch == '/' ||
               ch == '%';
    }

    static String infixToPostfix(String expression) {

        Stack<Character> stack = new Stack<>();
        String postfix = "";

        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            // Ignore spaces
            if (ch == ' ') {
                continue;
            }

            // Operand
            if (Character.isLetterOrDigit(ch)) {

                postfix = postfix + ch + " ";
            }

            // Opening parenthesis
            else if (ch == '(') {

                stack.push(ch);
            }

            // Closing parenthesis
            else if (ch == ')') {

                while (!stack.isEmpty()
                        && stack.peek() != '(') {

                    postfix = postfix + stack.pop() + " ";
                }

                if (!stack.isEmpty()) {
                    stack.pop();
                }
            }

            // Operator
            else if (isOperator(ch)) {

                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek())
                        >= precedence(ch)) {

                    postfix = postfix + stack.pop() + " ";
                }

                stack.push(ch);
            }
        }

        // Pop remaining operators
        while (!stack.isEmpty()) {

            postfix = postfix + stack.pop() + " ";
        }

        return postfix.trim();
    }


    // =====================================================
    // MAIN MENU
    // =====================================================

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        CircularQueue cq = new CircularQueue();
        PriorityQueue pq = new PriorityQueue();
        Deque dq = new Deque();

        int choice;

        do {

            System.out.println();
            System.out.println("========== DATA STRUCTURES LAB 4 ==========");
            System.out.println("1. Circular Queue");
            System.out.println("2. Priority Queue");
            System.out.println("3. Deque");
            System.out.println("4. Infix to Postfix");
            System.out.println("5. Exit");
            System.out.println("===========================================");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {

                // -----------------------------------------
                // CIRCULAR QUEUE
                // -----------------------------------------
                case 1:

                    int cqChoice;

                    do {

                        System.out.println("\n--- Circular Queue ---");
                        System.out.println("1. Enqueue");
                        System.out.println("2. Dequeue");
                        System.out.println("3. Peek");
                        System.out.println("4. Display");
                        System.out.println("5. Back to Main Menu");

                        System.out.print("Enter choice: ");
                        cqChoice = input.nextInt();

                        switch (cqChoice) {

                            case 1:
                                System.out.print("Enter value: ");
                                cq.enqueue(input.nextInt());
                                break;

                            case 2:
                                cq.dequeue();
                                break;

                            case 3:
                                cq.peek();
                                break;

                            case 4:
                                cq.display();
                                break;

                            case 5:
                                break;

                            default:
                                System.out.println("Invalid choice!");
                        }

                    } while (cqChoice != 5);

                    break;


                // -----------------------------------------
                // PRIORITY QUEUE
                // -----------------------------------------
                case 2:

                    int pqChoice;

                    do {

                        System.out.println("\n--- Priority Queue ---");
                        System.out.println("1. Insert");
                        System.out.println("2. Remove");
                        System.out.println("3. Display");
                        System.out.println("4. Back to Main Menu");

                        System.out.print("Enter choice: ");
                        pqChoice = input.nextInt();

                        switch (pqChoice) {

                            case 1:

                                System.out.print("Enter value: ");
                                int value = input.nextInt();

                                System.out.print("Enter priority: ");
                                int priority = input.nextInt();

                                pq.insert(value, priority);
                                break;

                            case 2:
                                pq.remove();
                                break;

                            case 3:
                                pq.display();
                                break;

                            case 4:
                                break;

                            default:
                                System.out.println("Invalid choice!");
                        }

                    } while (pqChoice != 4);

                    break;


                // -----------------------------------------
                // DEQUE
                // -----------------------------------------
                case 3:

                    int dqChoice;

                    do {

                        System.out.println("\n--- Deque ---");
                        System.out.println("1. Insert Front");
                        System.out.println("2. Insert Rear");
                        System.out.println("3. Delete Front");
                        System.out.println("4. Delete Rear");
                        System.out.println("5. Display");
                        System.out.println("6. Back to Main Menu");

                        System.out.print("Enter choice: ");
                        dqChoice = input.nextInt();

                        switch (dqChoice) {

                            case 1:
                                System.out.print("Enter value: ");
                                dq.insertFront(input.nextInt());
                                break;

                            case 2:
                                System.out.print("Enter value: ");
                                dq.insertRear(input.nextInt());
                                break;

                            case 3:
                                dq.deleteFront();
                                break;

                            case 4:
                                dq.deleteRear();
                                break;

                            case 5:
                                dq.display();
                                break;

                            case 6:
                                break;

                            default:
                                System.out.println("Invalid choice!");
                        }

                    } while (dqChoice != 6);

                    break;


                // -----------------------------------------
                // INFIX TO POSTFIX
                // -----------------------------------------
                case 4:

                    input.nextLine();

                    System.out.print("\nEnter Infix Expression: ");
                    String expression = input.nextLine();

                    String postfix = infixToPostfix(expression);

                    System.out.println("\nInfix Expression:");
                    System.out.println(expression);

                    System.out.println("\nPostfix Expression:");
                    System.out.println(postfix);

                    break;


                // -----------------------------------------
                // EXIT
                // -----------------------------------------
                case 5:

                    System.out.println("Program ended.");
                    break;

                default:

                    System.out.println("Invalid choice!");
            }

        } while (choice != 5);

        input.close();
    }
}

