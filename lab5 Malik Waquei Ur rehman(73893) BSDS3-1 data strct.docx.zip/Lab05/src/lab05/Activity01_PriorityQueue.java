/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab05;

/**
 *
 * @author Pc
 */
public class Activity01_PriorityQueue {

    // Maximum size of queue
    int maxSize = 5;

    // Arrays to store values and priorities
    int[] value = new int[maxSize];
    int[] priority = new int[maxSize];

    int size = 0;

    // Insert element with priority
    public void insert(int val, int pri) {

        if (size == maxSize) {
            System.out.println("Queue Overflow!");
            return;
        }
        value[size] = val;
        priority[size] = pri;
        size++;

        System.out.println("Inserted: " + val + " (Priority: " + pri + ")");
    }

    // Remove element according to priority
    public void remove() {

        if (size == 0) {
            System.out.println("Queue Underflow!");
            return;
        }

        // Find element with highest priority
        // Smaller priority number = higher priority
        int highest = 0;

        for (int i = 1; i < size; i++) {
            if (priority[i] < priority[highest]) {
                highest = i;
            }
        }

        System.out.println("Removed: " + value[highest]
                + " (Priority: " + priority[highest] + ")");

        // Shift remaining elements
        for (int i = highest; i < size - 1; i++) {
            value[i] = value[i + 1];
            priority[i] = priority[i + 1];
        }

        size--;
    }

    // Display all elements
    public void display() {

        if (size == 0) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.println("\nCurrent Priority Queue:");

        for (int i = 0; i < size; i++) {
            System.out.println("Value: " + value[i]
                    + "  Priority: " + priority[i]);
        }
    }

    // Main method
    public static void main(String[] args) {

        Activity01_PriorityQueue pq = new Activity01_PriorityQueue();

        // Insert elements
        pq.insert(10, 3);
        pq.insert(20, 1);
        pq.insert(30, 2);
        pq.insert(40, 1);

        // Display queue
        pq.display();

        // Remove according to priority
        pq.remove();
        pq.display();

        pq.remove();
        pq.display();

        pq.remove();
        pq.display();

        pq.remove();
        pq.display();
    }
}
    

