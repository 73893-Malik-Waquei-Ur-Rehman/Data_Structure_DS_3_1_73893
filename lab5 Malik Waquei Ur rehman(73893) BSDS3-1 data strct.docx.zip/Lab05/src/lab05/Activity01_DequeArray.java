/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab05;

/**
 *
 * @author Pc
 */
public class Activity01_DequeArray {
    
    int[] deque = new int[5];
    int front = -1;
    int rear = -1;

    // Insert from front
    public void insertFront(int value) {

        if ((front == 0 && rear == deque.length - 1) ||
            (front == rear + 1)) {
            System.out.println("Deque Overflow!");
            return;
        }

        if (front == -1) {
            front = 0;
            rear = 0;
        } 
        else if (front == 0) {
            front = deque.length - 1;
        } 
        else {
            front--;
        }

        deque[front] = value;

        System.out.println(value + " inserted at front.");
    }

    // Insert from rear
    public void insertRear(int value) {

        if ((front == 0 && rear == deque.length - 1) ||
            (front == rear + 1)) {
            System.out.println("Deque Overflow!");
            return;
        }

        if (front == -1) {
            front = 0;
            rear = 0;
        } 
        else if (rear == deque.length - 1) {
            rear = 0;
        } 
        else {
            rear++;
        }

        deque[rear] = value;

        System.out.println(value + " inserted at rear.");
    }

    // Delete from front
    public void deleteFront() {

        if (front == -1) {
            System.out.println("Deque Underflow!");
            return;
        }

        System.out.println(deque[front] + " deleted from front.");

        if (front == rear) {
            front = -1;
            rear = -1;
        } 
        else if (front == deque.length - 1) {
            front = 0;
        } 
        else {
            front++;
        }
    }

    // Delete from rear
    public void deleteRear() {

        if (front == -1) {
            System.out.println("Deque Underflow!");
            return;
        }

        System.out.println(deque[rear] + " deleted from rear.");

        if (front == rear) {
            front = -1;
            rear = -1;
        } 
        else if (rear == 0) {
            rear = deque.length - 1;
        } 
        else {
            rear--;
        }
    }

    // Display elements
    public void display() {

        if (front == -1) {
            System.out.println("Deque is empty.");
            return;
        }

        System.out.print("Current Deque: ");

        int i = front;

        while (true) {
            System.out.print(deque[i] + " ");

            if (i == rear) {
                break;
            }

            i = (i + 1) % deque.length;
        }

        System.out.println();
    }

    // Main method
    public static void main(String[] args) {

        Activity01_DequeArray d = new Activity01_DequeArray();

        // 1. Insertion from rear
        d.insertRear(10);
        d.insertRear(20);

        // 2. Insertion from front
        d.insertFront(5);
        d.insertFront(1);

        // Display
        d.display();

        // 3. Deletion from front
        d.deleteFront();

        // 4. Deletion from rear
        d.deleteRear();

        // Display current elements
        d.display();
    }
}

