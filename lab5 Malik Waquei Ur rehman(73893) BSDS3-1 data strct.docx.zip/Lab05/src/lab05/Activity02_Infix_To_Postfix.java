/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab05;

/**
 *
 * @author Pc
 */


import java.util.Scanner;
import java.util.Stack;

public class Activity02_Infix_To_Postfix {

    // Method to return precedence of operators
    public static int precedence(char operator) {

        if (operator == '+' || operator == '-') {
            return 1;
        }

        if (operator == '*' || operator == '/' || operator == '%') {
            return 2;
        }

        return 0;
    }

    // Method to check if character is an operator
    public static boolean isOperator(char ch) {
        return ch == '+' || ch == '-' ||
               ch == '*' || ch == '/' || ch == '%';
    }

    // Method to convert Infix to Postfix
    public static String infixToPostfix(String expression) {

        Stack<Character> stack = new Stack<>();
        String postfix = "";

        // Read expression from left to right
        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            // Ignore spaces
            if (ch == ' ') {
                continue;
            }

            // If operand, add directly to output
            if (Character.isLetterOrDigit(ch)) {
                postfix = postfix + ch + " ";
            }

            // If opening parenthesis, push it
            else if (ch == '(') {
                stack.push(ch);
            }

            // If closing parenthesis
            else if (ch == ')') {

                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix = postfix + stack.pop() + " ";
                }

                // Remove opening parenthesis
                if (!stack.isEmpty()) {
                    stack.pop();
                }
            }

            // If operator
            else if (isOperator(ch)) {

                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) >= precedence(ch)) {

                    postfix = postfix + stack.pop() + " ";
                }

                stack.push(ch);
            }
        }
        // Pop remaining operators
        while (!stack.isEmpty()) {
            postfix = postfix + stack.pop() + " ";
        }
        return postfix.trim();
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter Infix Expression: ");
        String expression = input.nextLine();

        String postfix = infixToPostfix(expression);

        System.out.println("\nInfix Expression:");
        System.out.println(expression);

        System.out.println("\nPostfix Expression:");
        System.out.println(postfix);

        input.close();
    }
}
