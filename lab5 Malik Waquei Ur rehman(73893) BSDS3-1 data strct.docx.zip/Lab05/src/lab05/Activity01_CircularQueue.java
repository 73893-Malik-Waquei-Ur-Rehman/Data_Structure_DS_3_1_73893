/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab05;

/**
 *
 * @author Pc
 */
public class Activity01_CircularQueue {
    
    private int[] queue = new int[5];
    private int front = -1;
    private int rear = -1;

    // Check if queue is empty
    public boolean isEmpty() {
        return front == -1;
    }

    // Check if queue is full
    public boolean isFull() {
        return (rear + 1) % queue.length == front;
    }

    // Insert an element
    public void enqueue(int value) {
        if (isFull()) {
            System.out.println("Queue Overflow! Queue is full.");
            return;
        }

        if (isEmpty()) {
            front = 0;
        }

        rear = (rear + 1) % queue.length;
        queue[rear] = value;

        System.out.println(value + " enqueued.");
    }

    // Remove an element
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow! Queue is empty.");
            return -1;
        }

        int value = queue[front];

        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % queue.length;
        }

        System.out.println(value + " dequeued.");
        return value;
    }

    // Display front element
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }

        System.out.println("Front element: " + queue[front]);
        return queue[front];
    }

    // Display all elements
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.print("Queue elements: ");

        int i = front;

        while (true) {
            System.out.print(queue[i] + " ");

            if (i == rear) {
                break;
            }

            i = (i + 1) % queue.length;
        }

        System.out.println();
    }

    // Main method
    public static void main(String[] args) {

         Activity01_CircularQueue q = new  Activity01_CircularQueue();

        // Demonstration
        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);
        q.enqueue(40);

        q.dequeue();
        q.dequeue();

        q.enqueue(50);
        q.enqueue(60);

        q.peek();
        q.display();

        // Testing overflow
        q.enqueue(70);
        q.enqueue(80);

        // Testing underflow
        q.dequeue();
        q.dequeue();
        q.dequeue();
        q.dequeue();
        q.dequeue();
        q.dequeue();
    }
}

