/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trading_management_system;


// MALIK WAQUEI UR REHMAN
// SAPID: 73893
// BS Data Science 3-1
// DATA STRUCTURE ASSIGNMENT #1


import java.util.Scanner;
public class Trading_management_System {

   
    // A. FINANCIAL ASSET

    static class Asset {
        int assetID;
        String assetName;
        String assetType;
        double currentPrice;
        double percentageChange;

        Asset(int assetID, String assetName, String assetType,
              double currentPrice, double percentageChange) {
            this.assetID = assetID;
            this.assetName = assetName;
            this.assetType = assetType;
            this.currentPrice = currentPrice;
            this.percentageChange = percentageChange;
        }

        void display() {
            System.out.printf(
                    "%-8d %-18s %-12s %-15.2f %-10.2f%%%n",
                    assetID, assetName, assetType,
                    currentPrice, percentageChange
            );
        }
    }

    // At least 10 assets as required by the assignment
    static Asset[] assets = {
            new Asset(1001, "Apple", "Stock", 225.50, 2.45),
            new Asset(1002, "Microsoft", "Stock", 510.25, 1.85),
            new Asset(1003, "Tesla", "Stock", 345.75, -1.20),
            new Asset(1004, "Bitcoin", "Crypto", 112500.00, 3.75),
            new Asset(1005, "Ethereum", "Crypto", 4200.50, 2.10),
            new Asset(1006, "Gold", "Commodity", 3850.75, 0.65),
            new Asset(1007, "Amazon", "Stock", 235.80, -0.95),
            new Asset(1008, "Google", "Stock", 198.40, 1.25),
            new Asset(1009, "Silver", "Commodity", 45.60, 0.80),
            new Asset(1010, "Nvidia", "Stock", 175.30, 4.15)
    };

    static Scanner scanner = new Scanner(System.in);
    
    // A. ARRAY OPERATIONS

    static void displayAllAssets() {
        System.out.println("\n================ ALL MARKET ASSETS ================");

        System.out.printf(
                "%-8s %-18s %-12s %-15s %-10s%n",
                "ID", "Asset Name", "Type", "Price", "Change"
        );

        System.out.println(
                "----------------------------------------------------------------"
        );

        for (Asset asset : assets) {
            asset.display();
        }
    }

    static void averagePrice() {
        double sum = 0;

        for (Asset asset : assets) {
            sum += asset.currentPrice;
        }

        double average = sum / assets.length;

        System.out.printf(
                "\nAverage Asset Price: %.2f%n", average
        );
    }

    static void highestPrice() {
        Asset highest = assets[0];

        for (int i = 1; i < assets.length; i++) {
            if (assets[i].currentPrice > highest.currentPrice) {
                highest = assets[i];
            }
        }

        System.out.println("\nHighest-Priced Asset:");
        highest.display();
    }

    static void lowestPrice() {
        Asset lowest = assets[0];

        for (int i = 1; i < assets.length; i++) {
            if (assets[i].currentPrice < lowest.currentPrice) {
                lowest = assets[i];
            }
        }

        System.out.println("\nLowest-Priced Asset:");
        lowest.display();
    }
    
    // B. LINEAR SEARCH

    static void linearSearch(int id) {

        for (int i = 0; i < assets.length; i++) {

            if (assets[i].assetID == id) {
                System.out.println("\nAsset Found using Linear Search:");
                assets[i].display();
                return;
            }
        }

        System.out.println("\nAsset not found.");
    }
    
    // B. BINARY SEARCH

    static Asset[] copyAssets() {

        Asset[] copy = new Asset[assets.length];

        for (int i = 0; i < assets.length; i++) {
            copy[i] = assets[i];
        }

        return copy;
    }

    static void sortByID(Asset[] arr) {

        // Simple selection sort by Asset ID
        for (int i = 0; i < arr.length - 1; i++) {

            int minIndex = i;

            for (int j = i + 1; j < arr.length; j++) {

                if (arr[j].assetID < arr[minIndex].assetID) {
                    minIndex = j;
                }
            }

            Asset temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }

    static void binarySearch(int id) {

        Asset[] sorted = copyAssets();
        sortByID(sorted);

        int low = 0;
        int high = sorted.length - 1;

        System.out.println("\nBinary Search Steps:");

        while (low <= high) {

            int mid = (low + high) / 2;

            System.out.println(
                    "Low = " + low +
                    ", High = " + high +
                    ", Mid = " + mid
            );

            if (sorted[mid].assetID == id) {

                System.out.println("\nAsset Found using Binary Search:");
                sorted[mid].display();
                return;

            } else if (id < sorted[mid].assetID) {

                high = mid - 1;

            } else {

                low = mid + 1;
            }
        }

        System.out.println("\nAsset not found.");
    }
    
    // C. BUBBLE SORT

    static void bubbleSort() {

        Asset[] arr = copyAssets();

        for (int i = 0; i < arr.length - 1; i++) {

            for (int j = 0; j < arr.length - i - 1; j++) {

                if (arr[j].currentPrice > arr[j + 1].currentPrice) {

                    Asset temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        System.out.println("\n========== BUBBLE SORT BY PRICE ==========");

        for (Asset asset : arr) {
            asset.display();
        }
    }
    
    // C. SELECTION SORT

    static void selectionSort() {

        Asset[] arr = copyAssets();

        for (int i = 0; i < arr.length - 1; i++) {

            int minIndex = i;

            for (int j = i + 1; j < arr.length; j++) {

                if (arr[j].assetID < arr[minIndex].assetID) {
                    minIndex = j;
                }
            }

            Asset temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }

        System.out.println("\n========== SELECTION SORT BY ID ==========");

        for (Asset asset : arr) {
            asset.display();
        }
    }
    
    // C. INSERTION SORT
    
    static void insertionSort() {

        Asset[] arr = copyAssets();

        for (int i = 1; i < arr.length; i++) {

            Asset key = arr[i];

            int j = i - 1;

            while (j >= 0 &&
                    arr[j].percentageChange > key.percentageChange) {

                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = key;
        }

        System.out.println(
                "\n========== INSERTION SORT BY PERCENTAGE CHANGE =========="
        );

        for (Asset asset : arr) {
            asset.display();
        }
    }
    
    // C. MERGE SORT
   
    static void mergeSort(Asset[] arr, int left, int right) {

        if (left < right) {

            int mid = (left + right) / 2;

            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);

            merge(arr, left, mid, right);
        }
    }

    static void merge(
            Asset[] arr,
            int left,
            int mid,
            int right) {

        int n1 = mid - left + 1;
        int n2 = right - mid;

        Asset[] L = new Asset[n1];
        Asset[] R = new Asset[n2];

        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }

        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }

        int i = 0;
        int j = 0;
        int k = left;

        while (i < n1 && j < n2) {

            if (L[i].currentPrice <= R[j].currentPrice) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }

            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    static void performMergeSort() {

        Asset[] arr = copyAssets();

        mergeSort(arr, 0, arr.length - 1);

        System.out.println("\n========== MERGE SORT BY PRICE ==========");

        for (Asset asset : arr) {
            asset.display();
        }
    }
    
    // C. QUICK SORT
   
    static void quickSort(
            Asset[] arr,
            int low,
            int high) {

        if (low < high) {

            int pivotIndex = partition(arr, low, high);

            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    static int partition(
            Asset[] arr,
            int low,
            int high) {

        // Last element is selected as pivot
        int pivot = arr[high].assetID;

        int i = low - 1;

        for (int j = low; j < high; j++) {

            if (arr[j].assetID < pivot) {

                i++;

                Asset temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Asset temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    static void performQuickSort() {

        Asset[] arr = copyAssets();

        quickSort(arr, 0, arr.length - 1);

        System.out.println("\n========== QUICK SORT BY ID ==========");

        for (Asset asset : arr) {
            asset.display();
        }
    }
    
    // D. SINGLY LINKED LIST - WATCHLIST
    
    static class WatchNode {

        Asset asset;
        WatchNode next;

        WatchNode(Asset asset) {
            this.asset = asset;
            this.next = null;
        }
    }

    static class WatchList {

        WatchNode head;

        // Insert asset into watchlist
        void insert(int id) {

            Asset asset = findAssetByID(id);

            if (asset == null) {
                System.out.println("Asset ID not found.");
                return;
            }

            WatchNode newNode = new WatchNode(asset);

            if (head == null) {
                head = newNode;
            } else {

                WatchNode current = head;

                while (current.next != null) {
                    current = current.next;
                }

                current.next = newNode;
            }

            System.out.println(
                    asset.assetName + " added to watchlist."
            );
        }

        // Delete asset from watchlist
        void delete(int id) {

            if (head == null) {
                System.out.println("Watchlist is empty.");
                return;
            }

            if (head.asset.assetID == id) {

                System.out.println(
                        head.asset.assetName +
                        " removed from watchlist."
                );

                head = head.next;
                return;
            }

            WatchNode current = head;

            while (current.next != null) {

                if (current.next.asset.assetID == id) {

                    System.out.println(
                            current.next.asset.assetName +
                            " removed from watchlist."
                    );

                    current.next = current.next.next;
                    return;
                }

                current = current.next;
            }

            System.out.println("Asset not found in watchlist.");
        }

        // Search watchlist
        void search(int id) {

            WatchNode current = head;

            while (current != null) {

                if (current.asset.assetID == id) {

                    System.out.println(
                            "Asset found in watchlist:"
                    );

                    current.asset.display();
                    return;
                }

                current = current.next;
            }

            System.out.println(
                    "Asset not found in watchlist."
            );
        }

        // Display watchlist
        void display() {

            if (head == null) {
                System.out.println("Watchlist is empty.");
                return;
            }

            System.out.println(
                    "\n========== INVESTOR WATCHLIST =========="
            );

            WatchNode current = head;

            while (current != null) {

                current.asset.display();

                current = current.next;
            }
        }
    }

    static WatchList watchList = new WatchList();
    
    // E. RECURSION - PORTFOLIO

    static class PortfolioItem {

        Asset asset;
        int quantity;

        PortfolioItem(Asset asset, int quantity) {
            this.asset = asset;
            this.quantity = quantity;
        }

        void display() {

            double value = asset.currentPrice * quantity;

            System.out.printf(
                    "%-18s Quantity: %-5d Price: %-12.2f Value: %.2f%n",
                    asset.assetName,
                    quantity,
                    asset.currentPrice,
                    value
            );
        }
    }

    static PortfolioItem[] portfolio = {
            new PortfolioItem(assets[0], 10),
            new PortfolioItem(assets[1], 5),
            new PortfolioItem(assets[3], 2),
            new PortfolioItem(assets[5], 8)
    };

    // Recursive portfolio calculation
    //
    // BASE CASE:
    // When index reaches the length of the portfolio.
    //
    // RECURSIVE CASE:
    // Current item's value + calculation of the remaining items.

    static double calculatePortfolioValue(
            PortfolioItem[] portfolio,
            int index) {

        // Base Case
        if (index == portfolio.length) {
            return 0;
        }

        // Recursive Case
        double currentValue =
                portfolio[index].asset.currentPrice *
                portfolio[index].quantity;

        return currentValue +
                calculatePortfolioValue(portfolio, index + 1);
    }

    // Recursive display of portfolio
    static void displayPortfolio(
            PortfolioItem[] portfolio,
            int index) {

        // Base Case
        if (index == portfolio.length) {
            return;
        }

        // Display current item
        portfolio[index].display();

        // Recursive Case
        displayPortfolio(portfolio, index + 1);
    }

    static void portfolioMenu() {

        System.out.println(
                "\n========== PORTFOLIO INFORMATION =========="
        );

        displayPortfolio(portfolio, 0);

        double total =
                calculatePortfolioValue(portfolio, 0);

        System.out.printf(
                "\nTotal Portfolio Value: %.2f%n",
                total
        );

        System.out.println("\nBase Case:");
        System.out.println(
                "When index reaches portfolio.length."
        );

        System.out.println("Recursive Case:");
        System.out.println(
                "Current asset value + remaining portfolio value."
        );
    }
    
    // F. STACK - RECENT TRANSACTIONS

    static class TransactionStack {

        static final int MAX = 5;

        String[] transactions = new String[MAX];

        int top = -1;

        // PUSH
        void push(String transaction) {

            if (top == MAX - 1) {

                System.out.println(
                        "Stack Overflow! Cannot add transaction."
                );

                return;
            }

            top++;

            transactions[top] = transaction;

            System.out.println(
                    "Transaction pushed: " + transaction
            );
        }

        // POP
        void pop() {

            if (top == -1) {

                System.out.println(
                        "Stack Underflow! No transaction to remove."
                );

                return;
            }

            System.out.println(
                    "Transaction popped: " +
                    transactions[top]
            );

            transactions[top] = null;

            top--;
        }

        // PEEK
        void peek() {

            if (top == -1) {

                System.out.println(
                        "Stack is empty."
                );

                return;
            }

            System.out.println(
                    "Top Transaction: " +
                    transactions[top]
            );
        }

        // DISPLAY
        void display() {

            if (top == -1) {

                System.out.println(
                        "Stack is empty."
                );

                return;
            }

            System.out.println(
                    "\n========== RECENT TRANSACTIONS =========="
            );

            for (int i = top; i >= 0; i--) {

                System.out.println(
                        transactions[i]
                );
            }

            System.out.println(
                    "\nStack follows LIFO: Last In, First Out."
            );
        }
    }

    static TransactionStack transactionStack =
            new TransactionStack();
    
    // G. QUEUE - TRADING ORDERS

    static class TradingQueue {

        static final int MAX = 5;

        String[] orders = new String[MAX];

        int front = 0;
        int rear = -1;
        int size = 0;

        // ENQUEUE
        void enqueue(String order) {

            if (size == MAX) {

                System.out.println(
                        "Queue Overflow! Cannot add order."
                );

                return;
            }

            rear = (rear + 1) % MAX;

            orders[rear] = order;

            size++;

            System.out.println(
                    "Order enqueued: " + order
            );
        }

        // DEQUEUE
        void dequeue() {

            if (size == 0) {

                System.out.println(
                        "Queue Underflow! No order to remove."
                );

                return;
            }

            System.out.println(
                    "Order dequeued: " +
                    orders[front]
            );

            orders[front] = null;

            front = (front + 1) % MAX;

            size--;
        }

        // PEEK
        void peek() {

            if (size == 0) {

                System.out.println(
                        "Queue is empty."
                );

                return;
            }

            System.out.println(
                    "Front Order: " +
                    orders[front]
            );
        }

        // DISPLAY
        void display() {

            if (size == 0) {

                System.out.println(
                        "Queue is empty."
                );

                return;
            }

            System.out.println(
                    "\n========== TRADING ORDERS =========="
            );

            int index = front;

            for (int i = 0; i < size; i++) {

                System.out.println(
                        orders[index]
                );

                index = (index + 1) % MAX;
            }

            System.out.println(
                    "\nQueue follows FIFO: First In, First Out."
            );
        }
    }

    static TradingQueue tradingQueue =
            new TradingQueue();
    
    // HELPER METHOD

    static Asset findAssetByID(int id) {

        for (Asset asset : assets) {

            if (asset.assetID == id) {
                return asset;
            }
        }

        return null;
    }

    // MENU 1 - MARKET ASSETS

    static void marketAssetMenu() {

        int choice;

        do {

            System.out.println(
                    "\n========== MANAGE MARKET ASSETS =========="
            );

            System.out.println("1. Display All Assets");
            System.out.println("2. Average Price");
            System.out.println("3. Highest-Priced Asset");
            System.out.println("4. Lowest-Priced Asset");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    displayAllAssets();
                    break;

                case 2:
                    averagePrice();
                    break;

                case 3:
                    highestPrice();
                    break;

                case 4:
                    lowestPrice();
                    break;

                case 0:
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    // MENU 2 - SEARCH

    static void searchMenu() {

        int choice;

        do {

            System.out.println(
                    "\n========== SEARCH ASSET =========="
            );

            System.out.println("1. Linear Search");
            System.out.println("2. Binary Search");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {

                System.out.print("Enter Asset ID: ");
                int id = scanner.nextInt();

                if (choice == 1) {
                    linearSearch(id);
                } else {
                    binarySearch(id);
                }
            }

        } while (choice != 0);
    }

    // MENU 3 - SORTING

    static void sortingMenu() {

        int choice;

        do {

            System.out.println(
                    "\n========== SORT MARKET ASSETS =========="
            );

            System.out.println("1. Bubble Sort");
            System.out.println("2. Selection Sort");
            System.out.println("3. Insertion Sort");
            System.out.println("4. Merge Sort");
            System.out.println("5. Quick Sort");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    bubbleSort();
                    break;

                case 2:
                    selectionSort();
                    break;

                case 3:
                    insertionSort();
                    break;

                case 4:
                    performMergeSort();
                    break;

                case 5:
                    performQuickSort();
                    break;

                case 0:
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    // MENU 4 - WATCHLIST

    static void watchlistMenu() {

        int choice;

        do {

            System.out.println(
                    "\n========== MANAGE WATCHLIST =========="
            );

            System.out.println("1. Insert Asset");
            System.out.println("2. Delete Asset");
            System.out.println("3. Search Asset");
            System.out.println("4. Display Watchlist");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:

                    System.out.print(
                            "Enter Asset ID to insert: "
                    );

                    int insertID = scanner.nextInt();

                    watchList.insert(insertID);

                    break;

                case 2:

                    System.out.print(
                            "Enter Asset ID to delete: "
                    );

                    int deleteID = scanner.nextInt();

                    watchList.delete(deleteID);

                    break;

                case 3:

                    System.out.print(
                            "Enter Asset ID to search: "
                    );

                    int searchID = scanner.nextInt();

                    watchList.search(searchID);

                    break;

                case 4:
                    watchList.display();
                    break;

                case 0:
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    // MENU 6 - TRANSACTIONS / STACK

    static void transactionMenu() {

        int choice;

        scanner.nextLine();

        do {

            System.out.println(
                    "\n========== MANAGE TRANSACTIONS =========="
            );

            System.out.println("1. Push Transaction");
            System.out.println("2. Pop Transaction");
            System.out.println("3. Peek Transaction");
            System.out.println("4. Display Transactions");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            scanner.nextLine();

            switch (choice) {

                case 1:

                    System.out.print(
                            "Enter transaction: "
                    );

                    String transaction =
                            scanner.nextLine();

                    transactionStack.push(transaction);

                    break;

                case 2:
                    transactionStack.pop();
                    break;

                case 3:
                    transactionStack.peek();
                    break;

                case 4:
                    transactionStack.display();
                    break;

                case 0:
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    // MENU 7 - TRADING ORDERS / QUEUE

    static void tradingOrderMenu() {

        int choice;

        scanner.nextLine();

        do {

            System.out.println(
                    "\n========== MANAGE TRADING ORDERS =========="
            );

            System.out.println("1. Enqueue Order");
            System.out.println("2. Dequeue Order");
            System.out.println("3. Peek Order");
            System.out.println("4. Display Orders");
            System.out.println("0. Back");

            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            scanner.nextLine();

            switch (choice) {

                case 1:

                    System.out.print(
                            "Enter trading order: "
                    );

                    String order =
                            scanner.nextLine();

                    tradingQueue.enqueue(order);

                    break;

                case 2:
                    tradingQueue.dequeue();
                    break;

                case 3:
                    tradingQueue.peek();
                    break;

                case 4:
                    tradingQueue.display();
                    break;

                case 0:
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    // MAIN MENU
    
    public static void main(String[] args) {

        int choice;

        System.out.println(
                "================================================"
        );

        System.out.println(
                "       FINTECH TRADING MANAGEMENT SYSTEM"
        );

        System.out.println(
                "================================================"
        );

        do {

            System.out.println(
                    "\n================ MAIN MENU ================"
            );

            System.out.println("1. Manage Market Assets");
            System.out.println("2. Search Asset");
            System.out.println("3. Sort Market Assets");
            System.out.println("4. Manage Watchlist");
            System.out.println("5. Calculate Portfolio Value");
            System.out.println("6. Manage Transactions");
            System.out.println("7. Manage Trading Orders");
            System.out.println("0. Exit");

            System.out.print("\nEnter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    marketAssetMenu();
                    break;

                case 2:
                    searchMenu();
                    break;

                case 3:
                    sortingMenu();
                    break;

                case 4:
                    watchlistMenu();
                    break;

                case 5:
                    portfolioMenu();
                    break;

                case 6:
                    transactionMenu();
                    break;

                case 7:
                    tradingOrderMenu();
                    break;

                case 0:

                    System.out.println(
                            "\nThank you for using the system!"
                    );

                    break;

                default:

                    System.out.println(
                            "Invalid choice. Please try again."
                    );
            }

        } while (choice != 0);

        scanner.close();
    }
}

    

