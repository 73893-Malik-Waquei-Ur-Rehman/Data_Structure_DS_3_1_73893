/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask03;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class exercise28 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.print("Enter a number (-1 to stop): ");
            int number = input.nextInt();

            if (number == -1) {
                break;
            }
            System.out.println("You entered: " + number);
        }
        System.out.println("Loop stopped.");
    }
}
