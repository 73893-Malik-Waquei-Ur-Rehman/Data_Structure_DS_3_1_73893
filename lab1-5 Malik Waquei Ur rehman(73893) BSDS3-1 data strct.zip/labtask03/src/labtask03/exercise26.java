/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask03;

/**
 *
 * @author Pc
 */
public class exercise26 {
    public static void main(String[] args) {
        int[] numbers = {10, 25, 7, 45, 18};

        int maximum = numbers[0];

        for (int number : numbers) {
            if (number > maximum) {
                maximum = number;
            }
        }
        System.out.println("Maximum value = " + maximum);
    }
}

