/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask03;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class exercise24 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int number;

        do {
            System.out.print("Enter a positive number: ");
            number = input.nextInt();
        } while (number <= 0);

        System.out.println("You entered: " + number);
    }
}

