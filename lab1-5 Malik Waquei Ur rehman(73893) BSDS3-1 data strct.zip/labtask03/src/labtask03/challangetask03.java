/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask03;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class challangetask03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of courses: ");
        int n = input.nextInt();
        int[] marks = new int[n];
        
        for (int i = 0; i < n; i++) {
            System.out.print("Enter mark for course " + (i + 1) + ": ");
            marks[i] = input.nextInt();
        }
        int sum = 0;
        int maximum = marks[0];
        for (int mark : marks) {
            sum += mark;

            if (mark > maximum) {
                maximum = mark;
            }
        }
        int passed = 0;
        for (int mark : marks) {
            if (mark >= 50) {
                passed++;
            }
        }
        System.out.println("\nTotal Marks = " + sum);
        System.out.println("Maximum Mark = " + maximum);
        System.out.println("Marks at least 50 = " + passed);
    }
}

