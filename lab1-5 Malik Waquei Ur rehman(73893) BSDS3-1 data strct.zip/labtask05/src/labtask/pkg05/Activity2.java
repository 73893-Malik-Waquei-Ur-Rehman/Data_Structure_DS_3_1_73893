/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask.pkg05;

/**
 *
 * @author Pc
 */
public class Activity2 {
  
    public static void main(String[] args) {

        int x = 5;

        System.out.println(x++);
        System.out.println(x);
        System.out.println(++x);
    }
}

