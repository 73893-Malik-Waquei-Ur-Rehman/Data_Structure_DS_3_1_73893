/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask.pkg05;

/**
 *
 * @author Pc
 */
public class exercise43 {
    public static void main(String[] args) {

        int attendance = 80;
        int marks = 65;

        boolean eligible = attendance >= 75 && marks >= 50;

        System.out.println("Eligible: " + eligible);
    }
}
