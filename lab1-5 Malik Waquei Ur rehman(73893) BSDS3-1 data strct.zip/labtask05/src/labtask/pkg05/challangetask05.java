/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask.pkg05;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class challangetask05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter first mark: ");
        int mark1 = input.nextInt();

        System.out.print("Enter second mark: ");
        int mark2 = input.nextInt();

        System.out.print("Enter third mark: ");
        int mark3 = input.nextInt();

        double average = (double) (mark1 + mark2 + mark3) / 3;
        boolean pass = average >= 50
                && mark1 >= 40
                && mark2 >= 40
                && mark3 >= 40;
        System.out.println("\nAverage = " + average);
        if (pass) {
            System.out.println("Result: Pass");
        } else {
            System.out.println("Result: Fail");
        }
    }
}

