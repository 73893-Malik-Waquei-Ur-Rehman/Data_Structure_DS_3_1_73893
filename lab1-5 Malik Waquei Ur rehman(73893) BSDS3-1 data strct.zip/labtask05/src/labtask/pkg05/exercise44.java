/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask.pkg05;

/**
 *
 * @author Pc
 */
public class exercise44 {
    public static void main(String[] args) {
        double number = 9.8;
        int result = (int) number;
        System.out.println("Double value: " + number);
        System.out.println("Integer value: " + result);
    }
}

