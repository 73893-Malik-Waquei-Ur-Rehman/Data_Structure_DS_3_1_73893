/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask.pkg05;

/**
 *
 * @author Pc
 */
public class exercise41 {
    public static void main(String[] args) {

        int a = 10;
        int b = 15;
        int c = 20;

        double average = (double) (a + b + c) / 3;

        System.out.println("Average = " + average);
    }
}
