/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class exercise16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter marks: ");
        int marks = input.nextInt();

        System.out.print("Enter attendance percentage: ");
        double attendance = input.nextDouble();

        if (marks >= 50 && attendance >= 75) {
            System.out.println("Student is eligible.");
        } else {
            System.out.println("Student is not eligible.");
        }
    }
    
}
