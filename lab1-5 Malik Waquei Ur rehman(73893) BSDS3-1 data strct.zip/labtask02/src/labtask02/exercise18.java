/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class exercise18 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number (1-3): ");
        int choice = input.nextInt();

        switch (choice) {
            case 1:
                System.out.println("You selected One.");
                break;

            case 2:
                System.out.println("You selected Two.");
                // No break here

            case 3:
                System.out.println("You selected Three.");
                break;

            default:
                System.out.println("Invalid choice.");
        }
    }
}
