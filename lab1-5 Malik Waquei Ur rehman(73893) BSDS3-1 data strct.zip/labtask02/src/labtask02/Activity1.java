/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labtask02;

/**
 *
 * @author Pc
 */import java.util.Scanner;

public class Activity1 {
    public static void main(String[] args) {
Scanner input = new Scanner(System.in);
System.out.print("Enter marks: ");
int marks = input.nextInt();
System.out.println("Marks = " + marks);
    }
}
