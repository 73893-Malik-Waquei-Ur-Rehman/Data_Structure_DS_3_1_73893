/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class Activity2 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter marks: ");
        int marks = input.nextInt();

        if (marks >= 85) {
            System.out.println("A");
        } 
        else if (marks >= 70) {
            System.out.println("B");
        } 
        else if (marks >= 50) {
            System.out.println("C");
        } 
        else {
            System.out.println("Fail");
        }

        input.close();
    }
}
