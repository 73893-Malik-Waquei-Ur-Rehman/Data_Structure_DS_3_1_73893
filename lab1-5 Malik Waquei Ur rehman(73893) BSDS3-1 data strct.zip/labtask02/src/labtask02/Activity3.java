/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author Pc
 */
import java.util.Scanner;
public class Activity3 {
   public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int choice = input.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Insert");
                break;
            case 2:
                System.out.println("Delete");
                break;
            default:
                System.out.println("Invalid choice");
                break;
        }
        input.close();
    }
}
