/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask;

/**
 *
 * @author Pc
 */
public class Activity2 {
    public static void main(String[] args){
    int age = 20;
double cgpa = 3.25;
char grade = 'A';
boolean passed = true;

System.out.println(age);
System.out.println(cgpa);
System.out.println(grade);
System.out.println(passed);
    }
  
}
