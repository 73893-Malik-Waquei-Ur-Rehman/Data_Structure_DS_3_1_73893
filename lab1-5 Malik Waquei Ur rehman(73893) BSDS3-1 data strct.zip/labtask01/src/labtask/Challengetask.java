/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask;

/**
 *
 * @author Pc
 */
public class Challengetask {
    public static void main(String[] args) {

        String name = "Waquei";
        int age = 19;
        int studentId = 73893;
        int semester = 3;
        double cgpa = 3.25;

        System.out.println("===== Student Information =====");
        System.out.println("Name       : " + name);
        System.out.println("Age        : " + age);
        System.out.println("Student ID : " + studentId);
        System.out.println("Semester   : " + semester);
        System.out.println("CGPA       : " + cgpa);
    }
    
}
