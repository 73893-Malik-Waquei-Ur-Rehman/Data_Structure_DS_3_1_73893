/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask;

/**
 *
 * @author Pc
 */
public class Exercise10 {
      public static void main(String[] args) {
        int studentName = 20;
        System.out.println(studentName);
    }
    
}
