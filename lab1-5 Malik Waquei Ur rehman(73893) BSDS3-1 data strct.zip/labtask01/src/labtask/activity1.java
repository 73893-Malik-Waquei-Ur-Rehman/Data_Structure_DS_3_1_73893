/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labtask;

/**
 *
 * @author Pc
 */
public class activity1 {
   
    public static void main(String[] args) {
       
        System.out.println("Welcome to Data Structures Lab");
    }
    
}
