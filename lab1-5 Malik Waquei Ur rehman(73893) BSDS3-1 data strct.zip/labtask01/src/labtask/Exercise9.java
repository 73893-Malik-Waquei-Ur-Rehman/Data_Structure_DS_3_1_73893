/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask;


public class Exercise9 {
     public static void main(String[] args) {
        
        String studentName = "Waquei";
        int studentAge = 19;
        int studentId = 73893;
        int semesterNumber = 3;
        double studentCgpa = 3.25;

        System.out.println("Name: " + studentName);
        System.out.println("Age: " + studentAge);
        System.out.println("Student ID: " + studentId);
        System.out.println("Semester: " + semesterNumber);
        System.out.println("CGPA: " + studentCgpa);
    }
}
