/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask;

/**
 *
 * @author Pc
 */
public class Exercise7 {
    public static void main(String[] args) {
        
        String name = "Waquei";
        int semesterNumber = 3;
        double cgpa = 3.25;

        System.out.println("Name: " + name);
        System.out.println("Semester: " + semesterNumber);
        System.out.println("CGPA: " + cgpa);
    }
    
}
