/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask04;

/**
 *
 * @author Pc
 */

class Book {
    String title;
    String author;
    double price;
    public Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }
    public void display() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: " + price);
        System.out.println();
    }
}
public class exercise35 {

    public static void main(String[] args) {
        Book book1 = new Book("Java Programming", "James Gosling", 5000);
        Book book2 = new Book("C++ Programming", "Bjarne Stroustrup", 4500);
        System.out.println("Book 1:");
        book1.display();

        System.out.println("Book 2:");
        book2.display();

       
        book1.price = 5500;
        System.out.println("After changing Book 1 price:");
        System.out.println("Book 1:");
        book1.display();
        System.out.println("Book 2:");
        book2.display();
    }
}


