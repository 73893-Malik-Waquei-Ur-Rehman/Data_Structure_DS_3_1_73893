/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask04;

/**
 *
 * @author Pc
 */
public class exercise34 {
    String title;
    String author;
    double price;
    public exercise34 (String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }
    public void display() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: " + price);
    }
    public void updatePrice(double newPrice) {
        price = newPrice;
    }
    public static void main(String[] args) {
        exercise34 book = new exercise34(
            "Java Programming",
            "James Gosling",
            5000
        );
        book.display();
        book.updatePrice(5500);
        System.out.println("\nAfter price update:");
        book.display();
    }
}

