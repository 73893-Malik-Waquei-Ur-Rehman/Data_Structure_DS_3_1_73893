/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask04;

/**
 *
 * @author Pc
 */
public class exercise33 {
    String title;
    String author;
    double price;

    public static void main(String[] args) {
        exercise33 book = new exercise33();
        
        book.title = "Data Structures";
        book.author = "James Gosling";
        book.price = 5000;

        System.out.println("Title: " + book.title);
        System.out.println("Author: " + book.author);
        System.out.println("Price: " + book.price);
    }
}
