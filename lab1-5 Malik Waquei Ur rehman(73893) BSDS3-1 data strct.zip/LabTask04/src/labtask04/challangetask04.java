/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask04;

/**
 *
 * @author Pc
 */

class BankAccount {
    private String accountHolder;
    private double balance;

    public BankAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Withdrawal denied. Insufficient balance.");
        }
    }
}
public class challangetask04 {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Ali", 10000);

        System.out.println("Account Holder: Ali");
        System.out.println("Initial Balance: " + account.getBalance());

        account.deposit(5000);
        System.out.println("Balance after deposit: " + account.getBalance());

        account.withdraw(3000);
        System.out.println("Balance after withdrawal: " + account.getBalance());

        // Attempt to withdraw more than the balance
        account.withdraw(15000);
        System.out.println("Final Balance: " + account.getBalance());
    }
}


