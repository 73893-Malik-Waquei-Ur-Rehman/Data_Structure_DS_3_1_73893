/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labtask04;





public class Activity1 {
    private int count;
    public Activity1() {
        count = 0;
    }
    public int getCount() {
        return count;
    }
    public void increment() {
        count++;
    }
    public static void main(String[] args) {
        Activity1 c = new Activity1();
        c.increment();
        c.increment();

        System.out.println(c.getCount());
    }
}



