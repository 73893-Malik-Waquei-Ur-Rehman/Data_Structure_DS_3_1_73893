/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask04;

/**
 *
 * @author Pc
 */

class Counter {
    private int count;
    public Counter(int initialValue) {
        count = initialValue;
    }
    public int getCount() {
        return count;
    }
    public void increment() {
        count++;
    }
    public void decrement() {
        count--;
    }
}
public class Activity3 {
    public static void main(String[] args) {
        Counter c = new Counter(10);

        c.increment();
        c.increment();
        c.decrement();

        System.out.println(c.getCount());
    }
}

