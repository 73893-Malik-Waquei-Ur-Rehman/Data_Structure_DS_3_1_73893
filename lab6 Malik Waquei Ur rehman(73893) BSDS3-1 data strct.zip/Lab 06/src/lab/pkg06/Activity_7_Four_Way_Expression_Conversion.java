/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg06;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Stack;

public class Activity_7_Four_Way_Expression_Conversion {

    // Operator precedence
    static int precedence(char ch) {
        if (ch == '+' || ch == '-') {
            return 1;
        }
        if (ch == '*' || ch == '/' || ch == '%') {
            return 2;
        }
        if (ch == '^') {
            return 3;
        }
        return 0;
    }

    // Check operator
    static boolean isOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '*'
                || ch == '/' || ch == '%' || ch == '^';
    }

    // 1. Infix to Postfix
    static String infixToPostfix(String expression) {

        Stack<Character> stack = new Stack<>();
        String postfix = "";

        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                postfix += ch;
            }

            else if (ch == '(') {
                stack.push(ch);
            }

            else if (ch == ')') {

                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix += stack.pop();
                }

                if (!stack.isEmpty()) {
                    stack.pop();
                }
            }

            else if (isOperator(ch)) {

                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) >= precedence(ch)) {

                    postfix += stack.pop();
                }

                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            postfix += stack.pop();
        }

        return postfix;
    }

    // 2. Postfix to Infix
    static String postfixToInfix(String expression) {

        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            else if (isOperator(ch)) {

                String operand2 = stack.pop();
                String operand1 = stack.pop();

                String result = "(" + operand1 + ch + operand2 + ")";

                stack.push(result);
            }
        }

        return stack.pop();
    }

    // 3. Infix to Prefix
    static String infixToPrefix(String expression) {

        Stack<Character> stack = new Stack<>();
        String reversed = "";

        // Reverse expression and swap parentheses
        for (int i = expression.length() - 1; i >= 0; i--) {

            char ch = expression.charAt(i);

            if (ch == '(') {
                reversed += ')';
            }
            else if (ch == ')') {
                reversed += '(';
            }
            else {
                reversed += ch;
            }
        }

        String postfix = "";

        for (int i = 0; i < reversed.length(); i++) {

            char ch = reversed.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                postfix += ch;
            }

            else if (ch == '(') {
                stack.push(ch);
            }

            else if (ch == ')') {

                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix += stack.pop();
                }

                if (!stack.isEmpty()) {
                    stack.pop();
                }
            }

            else if (isOperator(ch)) {

                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) > precedence(ch)) {

                    postfix += stack.pop();
                }

                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            postfix += stack.pop();
        }

        // Reverse postfix to get prefix
        String prefix = "";

        for (int i = postfix.length() - 1; i >= 0; i--) {
            prefix += postfix.charAt(i);
        }

        return prefix;
    }

    // 4. Prefix to Infix
    static String prefixToInfix(String expression) {

        Stack<String> stack = new Stack<>();

        for (int i = expression.length() - 1; i >= 0; i--) {

            char ch = expression.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            else if (isOperator(ch)) {

                String operand1 = stack.pop();
                String operand2 = stack.pop();

                String result = "(" + operand1 + ch + operand2 + ")";

                stack.push(result);
            }
        }

        return stack.pop();
    }

    // 5. Prefix to Postfix
    static String prefixToPostfix(String expression) {

        Stack<String> stack = new Stack<>();

        for (int i = expression.length() - 1; i >= 0; i--) {

            char ch = expression.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            else if (isOperator(ch)) {

                String operand1 = stack.pop();
                String operand2 = stack.pop();

                String result = operand1 + operand2 + ch;

                stack.push(result);
            }
        }

        return stack.pop();
    }

    // 6. Postfix to Prefix
    static String postfixToPrefix(String expression) {

        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            else if (isOperator(ch)) {

                String operand2 = stack.pop();
                String operand1 = stack.pop();

                String result = ch + operand1 + operand2;

                stack.push(result);
            }
        }

        return stack.pop();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println();
            System.out.println("========== EXPRESSION CONVERSION ==========");
            System.out.println("1. Infix to Postfix");
            System.out.println("2. Postfix to Infix");
            System.out.println("3. Infix to Prefix");
            System.out.println("4. Prefix to Infix");
            System.out.println("5. Prefix to Postfix");
            System.out.println("6. Postfix to Prefix");
            System.out.println("7. Exit");
            System.out.println("===========================================");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            if (choice >= 1 && choice <= 6) {

                System.out.print("Enter expression: ");
                String expression = sc.nextLine();

                String result = "";

                switch (choice) {

                    case 1:
                        result = infixToPostfix(expression);
                        break;

                    case 2:
                        result = postfixToInfix(expression);
                        break;

                    case 3:
                        result = infixToPrefix(expression);
                        break;

                    case 4:
                        result = prefixToInfix(expression);
                        break;

                    case 5:
                        result = prefixToPostfix(expression);
                        break;

                    case 6:
                        result = postfixToPrefix(expression);
                        break;
                }

                System.out.println();
                System.out.println("Original Expression: " + expression);
                System.out.println("Converted Expression: " + result);
            }

            else if (choice == 7) {
                System.out.println("Program ended.");
            }

            else {
                System.out.println("Invalid choice!");
            }

        } while (choice != 7);

        sc.close();
    }
}

    

