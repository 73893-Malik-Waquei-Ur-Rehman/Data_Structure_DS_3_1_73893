/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg06;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Stack;

public class Activity_6_Postfix_to_Prefix {
    static String postfixToPrefix(String expression) {

        Stack<String> stack = new Stack<>();

        // Read Postfix from left to right
        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            // If operand, push into stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            // If operator
            else {

                // Pop first operand
                String operand2 = stack.pop();

                // Pop second operand
                String operand1 = stack.pop();

                // Create Prefix expression
                String result = ch + operand1 + operand2;

                // Push result back into stack
                stack.push(result);
            }
        }

        // Final element is the Prefix expression
        return stack.pop();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Postfix Expression: ");
        String expression = sc.nextLine();

        String prefix = postfixToPrefix(expression);

        System.out.println("Prefix Expression: " + prefix);

        sc.close();
    }
}
    


    

