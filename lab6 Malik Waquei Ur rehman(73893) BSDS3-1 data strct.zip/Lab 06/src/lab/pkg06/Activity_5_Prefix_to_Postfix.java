/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg06;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Stack;

public class Activity_5_Prefix_to_Postfix {
    
    static String prefixToPostfix(String expression) {

        Stack<String> stack = new Stack<>();

        // Read Prefix expression from right to left
        for (int i = expression.length() - 1; i >= 0; i--) {

            char ch = expression.charAt(i);

            // If operand, push into stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            // If operator
            else {

                // Pop first operand
                String operand1 = stack.pop();

                // Pop second operand
                String operand2 = stack.pop();

                // Combine operands with operator
                String result = operand1 + operand2 + ch;

                // Push result back into stack
                stack.push(result);
            }
        }

        // Final stack element is the Postfix expression
        return stack.pop();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Prefix Expression: ");
        String expression = sc.nextLine();

        String postfix = prefixToPostfix(expression);

        System.out.println("Postfix Expression: " + postfix);

        sc.close();
    }
}

    



    
