/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg06;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Stack;

public class Activity_2_Postfix_to_Infix {

    static String postfixToInfix(String expression) {

        Stack<String> stack = new Stack<>();

        // Read expression from left to right
        for (int i = 0; i < expression.length(); i++) {

            char ch = expression.charAt(i);

            // If operand, push into stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }

            // If operator
            else {
                // Pop first operand
                String operand2 = stack.pop();

                // Pop second operand
                String operand1 = stack.pop();

                // Create infix expression
                String result = "(" + operand1 + ch + operand2 + ")";

                // Push result back into stack
                stack.push(result);
            }
        }

        // Final element is the Infix expression
        return stack.pop();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Postfix Expression: ");
        String expression = sc.nextLine();

        String result = postfixToInfix(expression);

        System.out.println("Infix Expression: " + result);

        sc.close();
    }
}

