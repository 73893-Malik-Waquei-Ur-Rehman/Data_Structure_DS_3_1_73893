/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg06;

/**
 *
 * @author Pc
 */

import java.util.Scanner;
import java.util.Stack;

public class Activity_3_Infix_to_Prefix {
    
    // Check operator precedence
    static int precedence(char ch) {
        if (ch == '+' || ch == '-') {
            return 1;
        }
        if (ch == '*' || ch == '/') {
            return 2;
        }
        if (ch == '^') {
            return 3;
        }
        return 0;
    }

    // Convert Infix to Prefix
    static String infixToPrefix(String expression) {

        Stack<Character> stack = new Stack<>();
        String result = "";

        // Reverse the expression
        String reversed = "";

        for (int i = expression.length() - 1; i >= 0; i--) {

            char ch = expression.charAt(i);

            if (ch == '(') {
                reversed = reversed + ')';
            } 
            else if (ch == ')') {
                reversed = reversed + '(';
            } 
            else {
                reversed = reversed + ch;
            }
        }

        // Read reversed expression
        for (int i = 0; i < reversed.length(); i++) {

            char ch = reversed.charAt(i);

            // Operand
            if (Character.isLetterOrDigit(ch)) {
                result = result + ch;
            }

            // Opening parenthesis
            else if (ch == '(') {
                stack.push(ch);
            }

            // Closing parenthesis
            else if (ch == ')') {

                while (!stack.isEmpty() && stack.peek() != '(') {
                    result = result + stack.pop();
                }

                if (!stack.isEmpty()) {
                    stack.pop();
                }
            }

            // Operator
            else {
                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) > precedence(ch)) {

                    result = result + stack.pop();
                }

                stack.push(ch);
            }
        }

        // Pop remaining operators
        while (!stack.isEmpty()) {
            result = result + stack.pop();
        }

        // Reverse result to get Prefix
        String prefix = "";

        for (int i = result.length() - 1; i >= 0; i--) {
            prefix = prefix + result.charAt(i);
        }

        return prefix;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Infix Expression: ");
        String expression = sc.nextLine();

        String prefix = infixToPrefix(expression);

        System.out.println("Prefix Expression: " + prefix);

        sc.close();
    }
}
